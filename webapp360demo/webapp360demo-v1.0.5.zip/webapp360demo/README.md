# webapp360demo plugin delivery

This repo is configured for private-source development with native WordPress updates and no per-site token setup.

## Target model

- Source code stays private in `Blu-Zetta/demos`.
- A GitHub Action publishes update assets (`zip`, `sha256`, `manifest.json`) to a public update channel repo.
- WordPress sites only install the plugin once, then update through normal WP update UI and auto-update toggle.

## One-time GitHub setup (required)

1. Create public repo: `Blu-Zetta/updates`.
2. In `Blu-Zetta/demos` repo settings, add secret `UPDATES_REPO_PAT`.
3. `UPDATES_REPO_PAT` must be a fine-grained token with `Contents: Read and write` on `Blu-Zetta/updates`.
4. Optional: add repo variable `UPDATES_REPO` if you want a different target repo path.

The plugin reads manifest from:

`https://raw.githubusercontent.com/Blu-Zetta/updates/main/webapp360demo/manifest.json`

You can override with constant if ever needed:

```php
define('BLUZETTA_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/ORG/REPO/main/webapp360demo/manifest.json');
```

## Release flow

1. Bump `Version` in `webapp360demo.php`.
2. Commit and push to `main`.
3. Push matching tag (`vX.Y`).
4. `Release Plugin` workflow:
   - builds zip + checksum
   - creates GitHub release in private repo
   - publishes zip/checksum/manifest to public update channel repo
5. WordPress detects update natively.

## WordPress site flow

1. Install plugin manually once.
2. Enable auto-updates for this plugin (optional but recommended).
3. No GitHub token required on the site when manifest channel is active.

## Fallback mode (private GitHub API)

If update channel repo is not configured, plugin falls back to GitHub API mode and may need token:

- `Settings -> Blu Zetta Updater`
- or `BLUZETTA_GITHUB_TOKEN` in `wp-config.php`

## Optional Azure deploy/rollback (CI)

Manual workflows remain available and are skipped unless Azure secrets are present.
