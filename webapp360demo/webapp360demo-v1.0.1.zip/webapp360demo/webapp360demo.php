<?php
/**
 * Plugin Name: Blu Zetta Demo Site Configs
 * Description: Demo site configuration toolkit for Blu Zetta client mockups, including fast template swaps, brand assets, and page settings. App by Blu Zetta.
 * Version: 1.0.1
 * Author: Blu Zetta
 * Author URI: https://bluzetta.com
 * Plugin URI: https://bluzetta.com
 * Update URI: https://github.com/Blu-Zetta/demos
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;

class BluZetta_Quick_Setup {
    // Default logo URLs (used for all industries on reset)
    const DEFAULT_HEADER_LOGO = 'https://demo.bluzetta.com/wp-content/uploads/2026/02/Dashboard-Blu-Zetta-Logo.png';
    const DEFAULT_FOOTER_LOGO = 'https://demo.bluzetta.com/wp-content/uploads/2026/02/Blu-Zetta-Signature-Logo-copy.png';
   
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_apply_template_changes', array($this, 'apply_changes'));
        add_action('wp_ajax_upload_captured_screenshot', array($this, 'upload_captured_screenshot'));
        add_action('wp_ajax_capture_scroll_video', array($this, 'capture_scroll_video'));
        add_action('wp_ajax_delete_captured_file', array($this, 'delete_captured_file'));
    }
    
    /**
     * Get Elementor kit ID
     */
    private function get_elementor_kit_id() {
        return (int) get_option('elementor_active_kit', 0);
    }
    
    /**
     * Get Elementor global colors from kit
     */
    private function get_elementor_global_colors() {
        $kit_id = $this->get_elementor_kit_id();
        if (!$kit_id) {
            return [];
        }
        
        $kit_settings = get_post_meta($kit_id, '_elementor_page_settings', true);
        if (empty($kit_settings) || !isset($kit_settings['system_colors'])) {
            return [];
        }
        
        $colors = [];
        foreach ($kit_settings['system_colors'] as $color) {
            if (isset($color['_id']) && isset($color['color'])) {
                $colors[$color['_id']] = $color['color'];
            }
        }
        
        // Also check custom_colors
        if (isset($kit_settings['custom_colors'])) {
            foreach ($kit_settings['custom_colors'] as $color) {
                if (isset($color['_id']) && isset($color['color'])) {
                    $colors[$color['_id']] = $color['color'];
                }
            }
        }
        
        return $colors;
    }
    
    /**
     * Get specific Elementor color by numeric ID
     */
    private function get_elementor_color_by_id($id) {
        $kit_id = $this->get_elementor_kit_id();
        if (!$kit_id) {
            return '';
        }
        
        $kit_settings = get_post_meta($kit_id, '_elementor_page_settings', true);
        if (empty($kit_settings)) {
            return '';
        }
        
        // Check custom_colors array - IDs 4 and 6 are custom colors
        if (isset($kit_settings['custom_colors']) && is_array($kit_settings['custom_colors'])) {
            foreach ($kit_settings['custom_colors'] as $index => $color) {
                // Custom color ID is based on array index + offset
                // ID 4 would be index 0 of custom_colors, ID 5 = index 1, ID 6 = index 2
                // Actually Elementor uses _id field, let's check both approaches
                if (isset($color['_id'])) {
                    // Extract numeric part if it's like "xyz123"
                    $color_id = $color['_id'];
                    if ($color_id == $id || preg_match('/^' . $id . '$/', $color_id)) {
                        return $color['color'] ?? '';
                    }
                }
            }
        }
        
        // Also check system_colors
        if (isset($kit_settings['system_colors']) && is_array($kit_settings['system_colors'])) {
            foreach ($kit_settings['system_colors'] as $color) {
                if (isset($color['_id']) && ($color['_id'] == $id)) {
                    return $color['color'] ?? '';
                }
            }
        }
        
        return '';
    }
    
    /**
     * Update Elementor global color by ID
     */
    private function update_elementor_color($id, $new_color) {
        $kit_id = $this->get_elementor_kit_id();
        if (!$kit_id) {
            return false;
        }
        
        $kit_settings = get_post_meta($kit_id, '_elementor_page_settings', true);
        if (empty($kit_settings)) {
            $kit_settings = [];
        }
        
        $updated = false;
        
        // Check and update in custom_colors
        if (isset($kit_settings['custom_colors']) && is_array($kit_settings['custom_colors'])) {
            foreach ($kit_settings['custom_colors'] as $index => &$color) {
                if (isset($color['_id']) && $color['_id'] == $id) {
                    $color['color'] = $new_color;
                    $updated = true;
                    break;
                }
            }
            unset($color);
        }
        
        // Check and update in system_colors
        if (!$updated && isset($kit_settings['system_colors']) && is_array($kit_settings['system_colors'])) {
            foreach ($kit_settings['system_colors'] as $index => &$color) {
                if (isset($color['_id']) && $color['_id'] == $id) {
                    $color['color'] = $new_color;
                    $updated = true;
                    break;
                }
            }
            unset($color);
        }
        
        if ($updated) {
            update_post_meta($kit_id, '_elementor_page_settings', $kit_settings);
            // Clear Elementor CSS cache
            if (class_exists('\Elementor\Plugin')) {
                \Elementor\Plugin::$instance->files_manager->clear_cache();
            }
            return true;
        }
        
        return false;
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Template Swapper',
            'WebApp Demo Creator',
            'manage_options',
            'template-swapper',
            array($this, 'admin_page'),
            'dashicons-welcome-widgets-menus',
            30
        );
    }
    
    public function enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_template-swapper') return;
        wp_enqueue_media();
        wp_enqueue_style('template-swapper-css', plugin_dir_url(__FILE__) . 'style.css');
        wp_enqueue_script('template-swapper-js', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), '1.0', true);
        wp_localize_script('template-swapper-js', 'swapperAjax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('swapper_nonce')
        ));
    }

    private function get_capture_temp_location() {
        $upload_dir = wp_upload_dir();
        return array(
            'dir' => trailingslashit($upload_dir['basedir']) . 'template-captures-temp',
            'url' => trailingslashit($upload_dir['baseurl']) . 'template-captures-temp'
        );
    }

    public function upload_captured_screenshot() {
        check_ajax_referer('swapper_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        $url = isset($_POST['url']) ? esc_url_raw(wp_unslash($_POST['url'])) : '';
        $filename = isset($_POST['filename']) ? sanitize_file_name(wp_unslash($_POST['filename'])) : 'capture.png';
        $width = isset($_POST['width']) ? intval($_POST['width']) : 1440;
        $height = isset($_POST['height']) ? intval($_POST['height']) : 900;
        $full_page = isset($_POST['fullPage']) ? filter_var($_POST['fullPage'], FILTER_VALIDATE_BOOLEAN) : false;
        $scroll_y = isset($_POST['scrollY']) ? intval($_POST['scrollY']) : 0;
        $wait = isset($_POST['wait']) ? intval($_POST['wait']) : 2000;
        $scroll_to_selector = isset($_POST['scrollToSelector']) ? wp_unslash($_POST['scrollToSelector']) : '';
        $click_selector = isset($_POST['clickSelector']) ? wp_unslash($_POST['clickSelector']) : '';

        if (empty($url)) {
            wp_send_json_error('Missing url');
        }

        $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
        $target_host = wp_parse_url($url, PHP_URL_HOST);
        if ($site_host && $target_host && $site_host !== $target_host) {
            wp_send_json_error('Invalid host');
        }

        $payload = array(
            'url' => $url,
            'width' => $width,
            'height' => $height,
            'fullPage' => $full_page,
            'scrollY' => $scroll_y,
            'wait' => $wait,
            'scrollToSelector' => $scroll_to_selector,
            'clickSelector' => $click_selector
        );

        $response = wp_remote_post('http://127.0.0.1:3001/capture', array(
            'timeout' => 90,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($response)) {
            wp_send_json_error('Capture service error: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        if ($code !== 200 || empty($body)) {
            wp_send_json_error('Capture failed (HTTP ' . $code . ')');
        }

        $location = $this->get_capture_temp_location();
        $base_dir = $location['dir'];
        $base_url = $location['url'];
        if (!wp_mkdir_p($base_dir)) {
            wp_send_json_error('Upload path unavailable');
        }

        $filename = wp_unique_filename($base_dir, $filename);
        $file_path = trailingslashit($base_dir) . $filename;
        $written = file_put_contents($file_path, $body);

        if ($written === false) {
            wp_send_json_error('Failed to write file');
        }

        $file_url = trailingslashit($base_url) . $filename;
        wp_send_json_success(array(
            'url' => $file_url,
            'path' => $file_path,
            'filename' => $filename
        ));
    }

    public function capture_scroll_video() {
        check_ajax_referer('swapper_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        $url = isset($_POST['url']) ? esc_url_raw(wp_unslash($_POST['url'])) : '';
        $filename = isset($_POST['filename']) ? sanitize_file_name(wp_unslash($_POST['filename'])) : 'capture.mp4';
        $width = isset($_POST['width']) ? intval($_POST['width']) : 1440;
        $height = isset($_POST['height']) ? intval($_POST['height']) : 900;
        $duration = isset($_POST['duration']) ? intval($_POST['duration']) : 11000;
        $wait = isset($_POST['wait']) ? intval($_POST['wait']) : 2000;

        if (empty($url)) {
            wp_send_json_error('Missing url');
        }

        $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
        $target_host = wp_parse_url($url, PHP_URL_HOST);
        if ($site_host && $target_host && $site_host !== $target_host) {
            wp_send_json_error('Invalid host');
        }

        $payload = array(
            'url' => $url,
            'width' => $width,
            'height' => $height,
            'duration' => $duration,
            'wait' => $wait
        );

        $response = wp_remote_post('http://127.0.0.1:3001/capture-video', array(
            'timeout' => 120,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($response)) {
            wp_send_json_error('Capture service error: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        if ($code !== 200 || empty($body)) {
            wp_send_json_error('Video capture failed (HTTP ' . $code . ')');
        }

        $location = $this->get_capture_temp_location();
        $base_dir = $location['dir'];
        $base_url = $location['url'];
        if (!wp_mkdir_p($base_dir)) {
            wp_send_json_error('Upload path unavailable');
        }

        $filename = wp_unique_filename($base_dir, $filename);
        $file_path = trailingslashit($base_dir) . $filename;
        $written = file_put_contents($file_path, $body);

        if ($written === false) {
            wp_send_json_error('Failed to write file');
        }

        $file_url = trailingslashit($base_url) . $filename;
        wp_send_json_success(array(
            'url' => $file_url,
            'path' => $file_path,
            'filename' => $filename
        ));
    }

    public function delete_captured_file() {
        check_ajax_referer('swapper_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized', 403);
        }

        $filename = isset($_POST['filename']) ? sanitize_file_name(wp_unslash($_POST['filename'])) : '';
        if (empty($filename)) {
            wp_send_json_error('Missing filename');
        }

        $filename = basename($filename);
        $location = $this->get_capture_temp_location();
        $base_dir = $location['dir'];
        $file_path = trailingslashit($base_dir) . $filename;

        if (!file_exists($file_path)) {
            wp_send_json_success(array('deleted' => false));
        }

        if (!unlink($file_path)) {
            wp_send_json_error('Failed to delete file');
        }

        wp_send_json_success(array('deleted' => true));
    }
    
    public function admin_page() {
        // Try to read colors from Elementor kit first
        $elementor_colors = $this->get_elementor_global_colors();
        
        // Light color = ID 4 (d03c845), Dark color = ID 6 (15d0d07)
        $light_color = $elementor_colors['d03c845'] ?? $elementor_colors['4'] ?? '#f5f6fb';
        $dark_color = $elementor_colors['15d0d07'] ?? $elementor_colors['6'] ?? '#05112f';
        
        // Debug: show what Elementor has stored
        $debug_colors = $elementor_colors;

        $tabs = [
            'roofing' => 'Roofing',
            'tradesmen' => 'Tradesmen',
            'builders' => 'Builders',
            'landscaping' => 'Landscaping',
            'fitness' => 'Fitness',
            'realestate' => 'Real Estate',
            'motors' => 'Motors',
            'salon' => 'Salon',
            'barber' => 'Barber',
            'spa' => 'Spa',
            'aesthetician' => 'Aesthetician',
            'nails' => 'Nail Tech',
            'makeup' => 'Make Up',
            'massage' => 'Massage',
            'restaurants' => 'Restaurants',
            'churches' => 'Churches',
            'venues' => 'Venues',
        ];

        $preview_pages = [
            'roofing' => 5474,
            'tradesmen' => 5474,
            'builders' => 5474,
            'landscaping' => 5474,
            'fitness' => 5299,
            'realestate' => 5474,
            'motors' => 5474,
            'salon' => 5299,
            'barber' => 5299,
            'spa' => 5299,
            'aesthetician' => 5299,
            'nails' => 5299,
            'makeup' => 5299,
            'massage' => 5299,
            'restaurants' => 0,
            'churches' => 0,
            'venues' => 0,
        ];

        $preview_urls = [];
        foreach ($preview_pages as $slug => $page_id) {
            $preview_urls[$slug] = $page_id ? get_permalink($page_id) : '';
        }
        
        // Get previously saved asset URLs to persist across page loads
        $saved_assets = get_option('template_swapper_saved_assets', []);
        // Page class map for conditional rendering on frontend
        $industry_page_classes = [
            'roofing' => 'elementor-5334',
            'tradesmen' => 'elementor-5334',
            'builders' => 'elementor-5334',
            'landscaping' => 'elementor-5334',
            'fitness' => 'elementor-5299',
            'realestate' => 'elementor-5334',
            'motors' => 'elementor-5334',
            'massage' => 'elementor-5299',
            'barber' => 'elementor-5299',
            'salon' => 'elementor-5299',
            'nails' => 'elementor-5299',
            'spa' => 'elementor-5299',
            'aesthetician' => 'elementor-5299',
            'makeup' => 'elementor-5299',
        ];

        // Logos & Banner section
        $roofing_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-9845574 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roof-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-dc4cd93 img'
                ],
            ],
        ];
        
        // Featured Image section (single slideshow background in column)
        $roofing_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-15e9e20 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roofing-Image-2.png'),
                ],
            ],
        ];
        
        // Service Images section (ElementsKit Image Box widgets)
        $roofing_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-ddb62e9 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roofing-Image-3.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-b857bac .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roofing-Image-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-a72bbea .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roofing-Image-4.png'),
                ],
            ],
        ];

        // ========== TRADESMEN TAB (Copy of Roofing) ==========
        $tradesmen_logos = $roofing_logos; // Reuse structure
        $tradesmen_featured = $roofing_featured;
        $tradesmen_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => ['.elementor-element-ddb62e9 .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Tradesman-Service-1.png')],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => ['.elementor-element-b857bac .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Tradesman-Service-2.png')],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => ['.elementor-element-a72bbea .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Tradesman-Service-3.png')],
            ],
        ];

        // ========== BUILDERS TAB (Copy of Roofing) ==========
        $builders_logos = $roofing_logos;
        $builders_featured = $roofing_featured;
        $builders_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => ['.elementor-element-ddb62e9 .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Builder-Service-1.png')],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => ['.elementor-element-b857bac .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Builder-Service-2.png')],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => ['.elementor-element-a72bbea .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Builder-Service-3.png')],
            ],
        ];

        // ========== LANDSCAPING TAB (Copy of Roofing) ==========
        $landscaping_logos = $roofing_logos;
        $landscaping_featured = $roofing_featured;
        $landscaping_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => ['.elementor-element-ddb62e9 .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Landscaping-Service-1.png')],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => ['.elementor-element-b857bac .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Landscaping-Service-2.png')],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => ['.elementor-element-a72bbea .elementskit-box-header img'],
                'presets' => [home_url('/wp-content/uploads/2026/01/Landscaping-Service-3.png')],
            ],
        ];


	    // ========== SALON TAB ==========

        $salon_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Banner-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Salon-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Salon-Banner-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];
        
        // salon Featured Image (single slideshow background)
        $salon_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Hairdresser-Image-1.png'),
                ],
            ],
        ];
        
        // salon Service Images
        $salon_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Hairdresser-Image-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Hairdresser-Image-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Hairdresser-Image-3.png'),
                ],
            ],
        ];
        
        // salon WooCommerce Product Images
        $salon_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Hairdresser-Image-2.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/salon-3-300x300.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Salon-Hairdresser-Image-3.png'),
                ],
            ],
        ];


        // ========== NAILS TAB ==========

        $nails_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Banner-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/nails-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/nails-Banner-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];
        
        // nails Featured Image (single slideshow background)
        $nails_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Hairdresser-Image-1.png'),
                ],
            ],
        ];
        
        // nails Service Images
        $nails_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Hairdresser-Image-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Hairdresser-Image-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Hairdresser-Image-3.png'),
                ],
            ],
        ];
        
        // nails WooCommerce Product Images
        $nails_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Hairdresser-Image-2.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-3-300x300.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/nails-Hairdresser-Image-3.png'),
                ],
            ],
        ];

   
        
        // ========== MASSAGE TAB ==========

        $massage_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roof-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];
        
        // Massage Featured Image (single slideshow background)
        $massage_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massage-3-1024x1024.png'),
                ],
            ],
        ];
        
        // Massage Service Images
        $massage_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-1024x1024.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element.elementor-element-8de1ec3 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Art-Corner-banner-3-scaled-e1741171677451.jpg'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2.png'),
                ],
            ],
        ];
        
        // Massage WooCommerce Product Images
        $massage_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-300x300.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massage-3-300x300.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2-300x300.png'),
                ],
            ],
        ];

        // ========== aesthetician TAB ==========

        $aesthetician_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roof-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];

        // aesthetician Featured Image (single slideshow background)
        $aesthetician_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/aesthetician-3-1024x1024.png'),
                ],
            ],
        ];

        // aesthetician Service Images
        $aesthetician_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-1024x1024.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element.elementor-element-8de1ec3 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Art-Corner-banner-3-scaled-e1741171677451.jpg'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2.png'),
                ],
            ],
        ];

        // aesthetician WooCommerce Product Images
        $aesthetician_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-300x300.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/aesthetician-3-300x300.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2-300x300.png'),
                ],
            ],
        ];

        // ========== barber TAB ==========

        $barber_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Banner-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Barber-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Barber-Banner-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];

        // barber Featured Image (single slideshow background)
        $barber_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'data-id="a658304"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-a658304 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Image-4.png'),
                ],
            ],
        ];

        // barber Service Images
        $barber_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Image-3.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Image-1.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Image-4.png'),
                ],
            ],
        ];

        // barber WooCommerce Product Images
        $barber_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    'div.bluzetta-product-card:nth-child(1) > div:nth-child(1) > img:nth-child(1)'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Image-2.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    'div.bluzetta-product-card:nth-child(2) > div:nth-child(1) > img:nth-child(1)'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Banner-2-scaled.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    'div.bluzetta-product-card:nth-child(3) > div:nth-child(1) > img:nth-child(1) '
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Barber-Image-3.png'),
                ],
            ],
        ];
        

        // ========== makeup TAB ==========

        $makeup_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Makeup-Artist-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Makeup-Artist-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Makeup-Artist-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];

        // makeup Featured Image (single slideshow background)
        $makeup_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/makeup-3-1024x1024.png'),
                ],
            ],
        ];

        // makeup Service Images
        $makeup_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-1024x1024.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Art-Corner-banner-3-scaled-e1741171677451.jpg'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2.png'),
                ],
            ],
        ];

        // makeup WooCommerce Product Images
        $makeup_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-300x300.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/makeup-3-300x300.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2-300x300.png'),
                ],
            ],
        ];        


        // ========== spa TAB ==========

        $spa_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5299 .elementor-element-f04471d img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Roof-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-3-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Roof-2-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];

        // spa Featured Image (single slideshow background)
        $spa_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/spa-3-1024x1024.png'),
                ],
            ],
        ];

        // spa Service Images
        $spa_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-1024x1024.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Art-Corner-banner-3-scaled-e1741171677451.jpg'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2.png'),
                ],
            ],
        ];

        // spa WooCommerce Product Images
        $spa_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Masdage-1-300x300.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/spa-3-300x300.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Massge-2-300x300.png'),
                ],
            ],
        ];


        // ========== FITNESS TAB ==========
        $fitness_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Fitness-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Fitness-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];
        
        $fitness_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Image-1.png'),
                ],
            ],
        ];
        
        $fitness_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Image-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Image-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Image-3.png'),
                ],
            ],
        ];
        
        $fitness_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Product-1.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Product-2.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Fitness-Product-3.png'),
                ],
            ],
        ];

        // ========== REAL ESTATE TAB ==========
        $realestate_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-9845574 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/RealEstate-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/RealEstate-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/RealEstate-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-dc4cd93 img'
                ],
            ],
        ];
        
        $realestate_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-15e9e20 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/RealEstate-Featured.png'),
                ],
            ],
        ];
        
        $realestate_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-ddb62e9 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/RealEstate-Service-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-b857bac .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/RealEstate-Service-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-a72bbea .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/RealEstate-Service-3.png'),
                ],
            ],
        ];

        // ========== MOTORS TAB ==========
        $motors_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-9845574 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Motors-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Motors-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Motors-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-dc4cd93 img'
                ],
            ],
        ];
        
        $motors_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-15e9e20 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Motors-Featured.png'),
                ],
            ],
        ];
        
        $motors_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-ddb62e9 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Motors-Service-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-b857bac .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Motors-Service-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-a72bbea .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Motors-Service-3.png'),
                ],
            ],
        ];

        // ========== VENUES TAB ==========
        $venues_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5299 .elementor-element-f04471d img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-788196f .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Venues-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Venues-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-a54d2f0 img'
                ],
            ],
        ];
        
        $venues_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-a658304 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Image-1.png'),
                ],
            ],
        ];
        
        $venues_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="149291d"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-149291d img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Image-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="d608ce1"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-d608ce1 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Image-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="47ab455"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-47ab455 img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Image-3.png'),
                ],
            ],
        ];
        
        $venues_products = [
            [
                'key' => 'product_1',
                'label' => 'Product 1 (ID: 5295)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5295 .woocommerce-product-gallery img',
                    '.post-5295 .wp-post-image',
                    '.product:has([data-product_id="5295"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Product-1.png'),
                ],
            ],
            [
                'key' => 'product_2',
                'label' => 'Product 2 (ID: 5294)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5294 .woocommerce-product-gallery img',
                    '.post-5294 .wp-post-image',
                    '.product:has([data-product_id="5294"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Product-2.png'),
                ],
            ],
            [
                'key' => 'product_3',
                'label' => 'Product 3 (ID: 5290)',
                'hint' => 'WooCommerce product image',
                'type' => 'product',
                'selectors' => [
                    '.post-5290 .woocommerce-product-gallery img',
                    '.post-5290 .wp-post-image',
                    '.product:has([data-product_id="5290"]) img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Venues-Product-3.png'),
                ],
            ],
        ];

        // ========== RESTAURANTS TAB ==========
        $restaurants_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-9845574 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Restaurant-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Restaurant-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Restaurant-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-dc4cd93 img'
                ],
            ],
        ];
        
        $restaurants_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-15e9e20 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Restaurant-Featured.png'),
                ],
            ],
        ];
        
        $restaurants_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-ddb62e9 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Restaurant-Service-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-b857bac .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Restaurant-Service-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-a72bbea .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Restaurant-Service-3.png'),
                ],
            ],
        ];

        // ========== CHURCHES TAB ==========
        $churches_logos = [
            [
                'key' => 'header_banner_logo',
                'label' => 'Header &amp; Banner Logo',
                'hint' => 'Shared file for header + banner',
                'selectors' => [
                    '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                    '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                ],
                'widths' => [
                    [
                        'label' => 'Header',
                        'selector' => '.elementor-5334 .elementor-element.elementor-element-3bcb5fc img',
                        'value' => 79,
                        'min' => 20,
                        'max' => 100,
                    ],
                    [
                        'label' => 'Banner',
                        'selector' => '.elementor-5474 .elementor-element.elementor-element-171f48a img',
                        'value' => 55,
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
            ],
            [
                'key' => 'banner_slider',
                'label' => 'Banner Slideshow',
                'hint' => 'Background slideshow image',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-9845574 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Church-Banner-1-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Church-Banner-2-scaled.png'),
                    home_url('/wp-content/uploads/2026/01/Church-Banner-3-scaled.png'),
                ],
            ],
            [
                'key' => 'footer_logo',
                'label' => 'Footer Logo',
                'hint' => 'Separate from header',
                'selectors' => [
                    '.elementor-element-dc4cd93 img'
                ],
            ],
        ];
        
        $churches_featured = [
            [
                'key' => 'featured_image',
                'label' => 'Featured Image',
                'hint' => 'Column background slideshow',
                'type' => 'slideshow',
                'selectors' => [
                    '.elementor-element-15e9e20 .elementor-background-slideshow__slide__image'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Church-Featured.png'),
                ],
            ],
        ];
        
        $churches_services = [
            [
                'key' => 'service_image_1',
                'label' => 'Service Image 1',
                'hint' => 'data-id="ddb62e9"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-ddb62e9 .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Church-Service-1.png'),
                ],
            ],
            [
                'key' => 'service_image_2',
                'label' => 'Service Image 2',
                'hint' => 'data-id="b857bac"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-b857bac .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Church-Service-2.png'),
                ],
            ],
            [
                'key' => 'service_image_3',
                'label' => 'Service Image 3',
                'hint' => 'data-id="a72bbea"',
                'type' => 'service',
                'selectors' => [
                    '.elementor-element-a72bbea .elementskit-box-header img'
                ],
                'presets' => [
                    home_url('/wp-content/uploads/2026/01/Church-Service-3.png'),
                ],
            ],
        ];


        ?>
        <div class="wrap qt-wrap">
            <div class="qt-color-panel">
                <div class="qt-color-input">
                    <span>Key Theme Color 1 (Light) <code>_id: 15d0d07</code></span>
                    <div class="qt-color-row">
                        <input type="text" id="dark-global-color" value="<?php echo esc_attr($dark_color); ?>" placeholder="#05112f" />
                        <input type="color" id="dark-global-color-picker" value="<?php echo esc_attr($dark_color); ?>" />
                        </div>
                    <small class="qt-color-note">Synced from Elementor Kit</small>
                    </div>
                <div class="qt-color-input">
                    <span>Key Theme Color 2 (Dark) <code>_id: d03c845</code></span>
                    <div class="qt-color-row">
                        <input type="text" id="light-global-color" value="<?php echo esc_attr($light_color); ?>" placeholder="#f5f6fb" />
                        <input type="color" id="light-global-color-picker" value="<?php echo esc_attr($light_color); ?>" />
                    </div>
                    <small class="qt-color-note">Synced from Elementor Kit</small>
                </div>
            </div>
            <?php if (!empty($debug_colors)): ?>
            <details class="qt-debug">
                <summary>Debug: Elementor Kit Colors</summary>
                <pre><?php echo esc_html(print_r($debug_colors, true)); ?></pre>
            </details>
            <?php endif; ?>
                
            <div class="qt-panel-section">
                <div class="qt-tabs" role="tablist">
                    <?php $first = true; ?>
                    <?php foreach ($tabs as $slug => $label): ?>
                        <button type="button"
                                class="qt-tab <?php echo $first ? 'active' : ''; ?>"
                                data-panel="<?php echo esc_attr($slug); ?>"
                                aria-controls="panel-<?php echo esc_attr($slug); ?>"
                                aria-selected="<?php echo $first ? 'true' : 'false'; ?>">
                            <?php echo esc_html($label); ?>
                        </button>
                        <?php $first = false; ?>
                    <?php endforeach; ?>
                </div>
                
                <div class="qt-preview-section">
                    <div class="qt-preview-label">
                        Previewing <span class="qt-preview-tab-label"><?php echo esc_html($tabs['roofing']); ?></span>
                    </div>
                    <div class="qt-preview-section-inner">
                        <div class="qt-preview-iframe-wrap">
                            <iframe id="qt-preview-iframe"
                                    class="qt-preview-iframe"
                                    src="<?php echo esc_url($preview_urls['roofing']); ?>"
                                    title="Roofing preview"
                                    loading="lazy"
                                    frameborder="0"
                                    scrolling="auto"></iframe>
                        </div>
                    </div>
                    <div id="qt-preview-empty"
                         class="qt-preview-empty"
                         <?php echo $preview_urls['roofing'] ? 'style="display:none;"' : ''; ?>>
                        Preview not configured for this tab yet.
                    </div>
                        </div>
                    </div>
                    
            <div class="qt-tab-panels">
                <?php $first = true; ?>
                <?php foreach ($tabs as $slug => $label): ?>
                    <div id="panel-<?php echo esc_attr($slug); ?>"
                         class="qt-tab-panel <?php echo $first ? 'active' : ''; ?>"
                         data-industry="<?php echo esc_attr($slug); ?>">
                        <?php if ($slug === 'roofing'): ?>
                            <!-- Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($roofing_logos as $target): ?>
                                    <div class="qt-target-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                       class="qt-slider width-slider"
                                                                       data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                       min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                       max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                       value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- Featured Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                            </div>
                                <?php foreach ($roofing_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($roofing_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif ($slug === 'spa'): ?>

                             <!-- SPA Logos & Banner Section -->
                             <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($spa_logos as $target): ?>
                                    <div class="qt-target-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                       class="qt-slider width-slider"
                                                                       data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                       min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                       max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                       value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- spa Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($spa_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                    
                            <!-- spa Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($spa_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- spa Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($spa_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif ($slug === 'massage'): ?>

                            <!-- MASSAGE Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($massage_logos as $target): ?>
                                    <div class="qt-target-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                       class="qt-slider width-slider"
                                                                       data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                       min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                       max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                       value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- Massage Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($massage_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                    
                            <!-- Massage Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($massage_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- Massage Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($massage_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif ($slug === 'nails'): ?>
                            
                             <!-- NAIL TECH Logos & Banner Section -->
                             <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($nails_logos as $target): ?>
                                    <div class="qt-target-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                       class="qt-slider width-slider"
                                                                       data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                       min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                       max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                       value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- nails Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($nails_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                    
                            <!-- nails Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($nails_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                
                            <!-- nails Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($nails_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                         data-key="<?php echo esc_attr($target['key']); ?>"
                                         data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                         data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif ($slug === 'salon'): ?>

                            <!-- SALON Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($salon_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- SALON Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($salon_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- SALON Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($salon_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- SALON Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($salon_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        
                        <?php elseif ($slug === 'makeup'): ?>

                            <!-- MAKEUP Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($makeup_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- MAKEUP Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($makeup_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- MAKEUP Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($makeup_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- MAKEUP Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($makeup_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif ($slug === 'aesthetician'): ?>

                            <!-- AESTHETICIAN Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($aesthetician_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- AESTHETICIAN Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($aesthetician_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- AESTHETICIAN Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($aesthetician_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- AESTHETICIAN Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($aesthetician_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                        <?php elseif ($slug === 'barber'): ?>

                            <!-- BARBER Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($barber_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Roof <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- BARBER Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($barber_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- BARBER Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($barber_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- BARBER Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($barber_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                        <?php elseif ($slug === 'fitness'): ?>

                            <!-- FITNESS Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($fitness_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- FITNESS Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($fitness_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- FITNESS Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($fitness_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- FITNESS Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($fitness_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'realestate'): ?>

                            <!-- REAL ESTATE Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($realestate_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- REAL ESTATE Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                            </div>
                                <?php foreach ($realestate_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- REAL ESTATE Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($realestate_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'motors'): ?>

                            <!-- MOTORS Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($motors_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- MOTORS Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                            </div>
                                <?php foreach ($motors_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- MOTORS Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($motors_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'venues'): ?>

                            <!-- VENUES Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($venues_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- VENUES Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($venues_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- VENUES Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                            </div>
                                <?php foreach ($venues_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- VENUES Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($venues_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'restaurants'): ?>

                            <!-- RESTAURANTS Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($restaurants_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- RESTAURANTS Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                            </div>
                                <?php foreach ($restaurants_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- RESTAURANTS Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($restaurants_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'churches'): ?>

                            <!-- CHURCHES Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($churches_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- CHURCHES Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                            </div>
                                <?php foreach ($churches_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- CHURCHES Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($churches_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        
                            <?php elseif ($slug === 'tradesmen'): ?>

                            <!-- TRADESMEN Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($tradesmen_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- TRADESMEN Featured Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                                </div>
                                <?php foreach ($tradesmen_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- TRADESMEN Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($tradesmen_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'builders'): ?>

                            <!-- BUILDERS Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($builders_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- BUILDERS Featured Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                                </div>
                                <?php foreach ($builders_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- BUILDERS Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($builders_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'landscaping'): ?>

                            <!-- LANDSCAPING Logos & Banner Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($landscaping_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- LANDSCAPING Featured Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Images</h2>
                                    <p>Column background slideshows. Click default to revert.</p>
                                </div>
                                <?php foreach ($landscaping_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- LANDSCAPING Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($landscaping_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php elseif ($slug === 'fitness'): ?>

                            <!-- FITNESS Logos & Banner Section (BEAUTY TEMPLATE - 4 CARDS) -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <div class="qt-card-title-row">
                                        <div>
                                            <h2>Logos & Banner</h2>
                                            <p>Header and banner logos share one file. Slideshow updates background images.</p>
                                        </div>
                                        <button type="button" class="button qt-reset-card" data-card="logos">
                                            ↻ Reset to Defaults
                                        </button>
                                    </div>
                                </div>
                                <?php foreach ($fitness_logos as $target): ?>
                                    <div class="qt-target-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-target-header">
                                            <strong><?php echo $target['label']; ?></strong>
                                            <?php if (!empty($target['hint'])): ?>
                                                <span class="qt-target-hint"><?php echo esc_html($target['hint']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="qt-target-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="https://example.com/new-image.png" />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                            <?php if (!empty($target['presets'])): ?>
                                                <div class="qt-preset-thumbnails">
                                                    <div class="qt-thumb qt-thumb-current active" data-preset="">
                                                        <div class="qt-thumb-img qt-thumb-placeholder">
                                                            <span>Current</span>
                                                        </div>
                                                        <span class="qt-thumb-label">Selected</span>
                                                    </div>
                                                    <?php foreach ($target['presets'] as $i => $preset_url): ?>
                                                        <div class="qt-thumb qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>">
                                                            <div class="qt-thumb-img" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                            <span class="qt-thumb-label">Preset <?php echo $i + 1; ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($target['widths'])): ?>
                                                <div class="qt-slider-grid">
                                                    <?php foreach ($target['widths'] as $width): ?>
                                                        <div class="qt-slider-row">
                                                            <label><?php echo esc_html($width['label']); ?></label>
                                                            <div class="qt-slider-wrap">
                                                                <input type="range"
                                                                    class="qt-slider width-slider"
                                                                    data-width-selector="<?php echo esc_attr($width['selector']); ?>"
                                                                    min="<?php echo esc_attr($width['min'] ?? 20); ?>"
                                                                    max="<?php echo esc_attr($width['max'] ?? 100); ?>"
                                                                    value="<?php echo esc_attr($width['value']); ?>" />
                                                                <span class="qt-slider-value"><?php echo esc_attr($width['value']); ?>%</span>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- FITNESS Featured Image Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Featured Image</h2>
                                    <p>Column background slideshow. Click default to revert.</p>
                                </div>
                                <?php foreach ($fitness_featured as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- FITNESS Service Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Service Images</h2>
                                    <p>Images auto-fit to template dimensions. Click default to revert.</p>
                                </div>
                                <?php foreach ($fitness_services as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- FITNESS Product Images Section -->
                            <div class="qt-card">
                                <div class="qt-card-header">
                                    <h2>Product Images</h2>
                                    <p>WooCommerce product images. Click default to revert.</p>
                                </div>
                                <?php foreach ($fitness_products as $target): ?>
                                    <div class="qt-target-row qt-service-row"
                                        data-key="<?php echo esc_attr($target['key']); ?>"
                                        data-selectors="<?php echo esc_attr(wp_json_encode($target['selectors'])); ?>"
                                        data-type="<?php echo esc_attr($target['type'] ?? 'default'); ?>">
                                        <div class="qt-service-label">
                                            <strong><?php echo esc_html($target['label']); ?></strong>
                                        </div>
                                        <div class="qt-service-inputs">
                                            <div class="input-with-button">
                                                <input type="text" class="new-image-url" placeholder="Paste URL or select media..." />
                                                <button type="button" class="button select-media-button">Media</button>
                                            </div>
                                        </div>
                                        <?php if (!empty($target['presets'])): ?>
                                            <div class="qt-service-thumbs">
                                                <div class="qt-thumb-inline qt-thumb-current active" data-preset="">
                                                    <div class="qt-thumb-img-inline qt-thumb-placeholder-inline">
                                                        <span>?</span>
                                                    </div>
                                                </div>
                                                <?php foreach ($target['presets'] as $preset_url): ?>
                                                    <div class="qt-thumb-inline qt-thumb-preset" data-preset="<?php echo esc_attr($preset_url); ?>" title="Revert to default">
                                                        <div class="qt-thumb-img-inline" style="background-image: url('<?php echo esc_attr($preset_url); ?>');"></div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                        <?php else: ?>
                            <div class="qt-card qt-card-empty">
                                <p><?php echo esc_html(sprintf('%s tab is coming soon with its own swap set.', $label)); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php $first = false; ?>
                <?php endforeach; ?>
                </div>
                
            <div class="qt-actions">
                    <button type="button" id="apply-changes" class="button button-primary button-hero">
                    Push Changes To Live Site
                    </button>
                    <button type="button" id="preview-changes" class="button button-secondary">
                    Preview Payload
                </button>
                <div class="qt-capture-row">
                    <input type="text" id="capture-client-name" placeholder="Client Name" class="qt-client-name-input" />
                    <button type="button" id="capture-assets" class="button button-primary">
                        Start Capture
                    </button>
                </div>
            </div>
                
            <div id="capture-status" class="qt-capture-status" style="display:none;">
                <div class="capture-progress">
                    <span class="capture-spinner"></span>
                    <span class="capture-text">Generating assets...</span>
            </div>
            </div>
                
            <div id="swapper-results" class="qt-results" role="status" aria-live="polite"></div>
            
            <div id="capture-review-modal" class="qt-capture-modal" style="display:none;">
                <div class="qt-modal-backdrop"></div>
                <div class="qt-modal-content" role="dialog" aria-modal="true" aria-labelledby="qt-capture-modal-title">
                    <div class="qt-modal-header">
                        <h3 id="qt-capture-modal-title">Review Captures</h3>
                        <button type="button" class="qt-modal-close" aria-label="Close">×</button>
                    </div>
                    <div class="qt-modal-body">
                        <div class="qt-capture-grid"></div>
                    </div>
                    <div class="qt-modal-footer">
                        <button type="button" class="button button-secondary qt-reject-captures">Reject & Delete</button>
                        <button type="button" class="button button-primary qt-approve-captures">Approve</button>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
            .qt-wrap {
                max-width: 1180px;
                margin: 0 auto;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                color: #fff;
            }
            .qt-color-panel {
                margin-top: 20px;
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
                gap: 16px;
            }
            .qt-card-title-row {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                gap: 20px;
            }
            .qt-reset-card {
                flex-shrink: 0;
                white-space: nowrap;
            }
            .qt-color-input {
                background: #030c2e;
                border: 1px solid rgba(255, 255, 255, 0.08);
                padding: 18px;
                border-radius: 14px;
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
            }
            .qt-color-input span {
                display: block;
                font-size: 12px;
                color: rgba(255, 255, 255, 0.65);
                margin-bottom: 6px;
            }
            .qt-color-row {
                display: flex;
                gap: 12px;
            }
            .qt-color-row input[type="text"] {
                flex: 1;
                padding: 10px 14px;
                border-radius: 10px;
                border: 1px solid rgba(255, 255, 255, 0.2);
                background: rgba(8, 15, 54, 0.9);
                color: #fff;
            }
            .qt-color-row input[type="color"] {
                width: 46px;
                height: 46px;
                border-radius: 8px;
                border: none;
                cursor: pointer;
            }
            .qt-capture-row {
                display: flex;
                gap: 10px;
                align-items: center;
            }
            .qt-client-name-input {
                padding: 8px 12px;
                border-radius: 8px;
                border: 1px solid rgba(255,255,255,0.2);
                background: rgba(6,9,45,0.9);
                color: #fff;
                width: 200px;
            }
            .qt-capture-modal {
                position: fixed;
                inset: 0;
                display: none;
                align-items: center;
                justify-content: center;
                z-index: 99999;
            }
            .qt-capture-modal.active {
                display: flex;
            }
            .qt-modal-backdrop {
                position: absolute;
                inset: 0;
                background: rgba(0, 0, 0, 0.72);
            }
            .qt-modal-content {
                position: relative;
                width: 92%;
                max-width: 980px;
                max-height: 88vh;
                background: #0b102a;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 16px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.55);
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }
            .qt-modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 16px 20px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            }
            .qt-modal-header h3 {
                margin: 0;
                font-size: 18px;
                color: #fff;
            }
            .qt-modal-close {
                background: transparent;
                border: none;
                color: rgba(255, 255, 255, 0.7);
                font-size: 24px;
                cursor: pointer;
                line-height: 1;
            }
            .qt-modal-body {
                padding: 16px 20px;
                overflow: auto;
            }
            .qt-capture-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                gap: 14px;
            }
            .qt-capture-item {
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
                padding: 10px;
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            .qt-capture-thumb {
                width: 100%;
                aspect-ratio: 1 / 1;
                background: #000;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                overflow: hidden;
            }
            .qt-capture-item img,
            .qt-capture-item video {
                width: 100%;
                border-radius: 8px;
                background: #000;
                max-width: 100%;
                max-height: 100%;
                width: auto;
                height: auto;
            }
            .qt-capture-item span {
                font-size: 12px;
                color: rgba(255, 255, 255, 0.7);
                word-break: break-all;
            }
            .qt-modal-footer {
                padding: 14px 20px;
                display: flex;
                justify-content: flex-end;
                gap: 10px;
                border-top: 1px solid rgba(255, 255, 255, 0.08);
            }
            .qt-tab {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.18);
                color: #fff;
                padding: 10px 24px;
                border-radius: 999px;
                cursor: pointer;
                transition: all 0.25s ease;
            }
            .qt-tab.active {
                background: #fff;
                color: #02005a;
                border-color: transparent;
                box-shadow: 0 10px 30px rgba(1, 16, 50, 0.25);
            }
            .qt-panel-section {
                margin-top: 24px;
                background: #030248;
                border-radius: 16px;
                padding: 18px;
                border: 1px solid rgba(255, 255, 255, 0.08);
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 18px;
            }
            .qt-tabs {
                width: 100%;
                display: flex;
                justify-content: center;
                gap: 10px;
                flex-wrap: wrap;
            }
            .qt-preview-section {
                margin-top: 16px;
                width: 80%;
                border-radius: 12px;
                overflow: hidden;
                background: #fff;
                border: 1px solid rgba(255,255,255,0.1);
            }
            .qt-preview-label {
                font-size: 14px;
                color: #fff;
                font-weight: 600;
                text-align: center;
                background: #02005a;
                padding: 12px 16px;
            }
            .qt-preview-section-inner {
                width: 100%;
                overflow: hidden;
                background: #fff;
                position: relative;
            }
            .qt-preview-iframe-wrap {
                width: 1440px;
                height: 900px;
                transform-origin: top left;
            }
            .qt-preview-iframe {
                width: 1440px;
                height: 900px;
                border: none;
                display: block;
                background: #fff;
            }
            .qt-preview-empty {
                padding: 60px 20px;
                color: rgba(255, 255, 255, 0.7);
                font-size: 14px;
                text-align: center;
                background: rgba(0,0,0,0.2);
            }
            .qt-color-note {
                display: block;
                margin-top: 6px;
                font-size: 11px;
                color: rgba(255,255,255,0.5);
            }
            .qt-debug {
                margin-top: 16px;
                background: rgba(0,0,0,0.3);
                border-radius: 8px;
                padding: 12px;
                font-size: 12px;
            }
            .qt-debug summary {
                cursor: pointer;
                color: rgba(255,255,255,0.7);
                font-weight: 600;
            }
            .qt-debug pre {
                margin: 10px 0 0;
                padding: 10px;
                background: rgba(0,0,0,0.4);
                border-radius: 6px;
                color: #aef;
                font-size: 11px;
                overflow-x: auto;
                white-space: pre-wrap;
            }
            .qt-tab-panels {
                margin-top: 18px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 16px;
                background: #010038;
                overflow: hidden;
            }
            .qt-tab-panel {
                display: none;
                padding: 24px 32px;
            }
            .qt-tab-panel.active {
                display: block;
            }

            .qt-card-header {
                margin-bottom: 16px;
            }
            .qt-card-header h2 {
                margin: 0;
            }
            .qt-card-header p {
                margin: 4px 0 0;
                color: rgba(255, 255, 255, 0.65);
                font-size: 14px;
            }
            .qt-card-empty {
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 160px;
                color: rgba(255, 255, 255, 0.6);
                font-size: 14px;
            }
            .qt-target-row {
                margin-bottom: 18px;
                padding: 14px;
                border-radius: 12px;
                1px solid rgba(255, 255, 255, 0.36);
                background: rgba(255, 255, 255, 0.02);
            }
            .qt-target-row:last-child {
                margin-bottom: 0;
            }
            .qt-target-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
            }
            .qt-target-header strong {
                font-size: 16px;
            }
            .qt-target-hint {
                font-size: 12px;
                color: rgba(255, 255, 255, 0.55);
            }
            .qt-target-inputs {
                display: flex;
                flex-direction: column;
                gap: 12px;
            }
            .input-with-button {
                display: flex;
                gap: 10px;
            }
            .input-with-button input[type="text"] {
                flex: 1;
                padding: 10px 14px;
                border-radius: 10px;
                border: 1px solid rgba(255, 255, 255, 0.15);
                background: rgba(6, 9, 45, 0.9);
                color: #fff;
            }
            .input-with-button .button {
                border-radius: 10px;
                padding: 10px 16px;
                font-size: 13px;
            }
            .qt-slider-grid {
                display: flex;
                flex-direction: column;
                gap: 12px;
                margin-top: 12px;
            }
            .qt-slider-row {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .qt-slider-row label {
                min-width: 60px;
                font-size: 12px;
                color: rgba(255, 255, 255, 0.7);
                font-weight: 500;
            }
            .qt-slider-wrap {
                flex: 1;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .qt-slider {
                flex: 1;
                -webkit-appearance: none;
                appearance: none;
                height: 6px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 3px;
                cursor: pointer;
            }
            .qt-slider::-webkit-slider-thumb {
                -webkit-appearance: none;
                appearance: none;
                width: 18px;
                height: 18px;
                border-radius: 50%;
                background: linear-gradient(135deg, #00a5ff 0%, #1a4de8 100%);
                cursor: grab;
                box-shadow: 0 2px 6px rgba(0, 165, 255, 0.4);
                transition: transform 0.15s ease, box-shadow 0.15s ease;
            }
            .qt-slider::-webkit-slider-thumb:hover {
                transform: scale(1.15);
                box-shadow: 0 3px 10px rgba(0, 165, 255, 0.6);
            }
            .qt-slider::-webkit-slider-thumb:active {
                cursor: grabbing;
                transform: scale(1.1);
            }
            .qt-slider::-moz-range-thumb {
                width: 18px;
                height: 18px;
                border-radius: 50%;
                background: linear-gradient(135deg, #00a5ff 0%, #1a4de8 100%);
                cursor: grab;
                border: none;
                box-shadow: 0 2px 6px rgba(0, 165, 255, 0.4);
            }
            .qt-slider::-moz-range-track {
                height: 6px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 3px;
            }
            .qt-slider-value {
                min-width: 45px;
                padding: 4px 8px;
                background: rgba(0, 165, 255, 0.15);
                border: 1px solid rgba(0, 165, 255, 0.3);
                border-radius: 6px;
                font-size: 12px;
                font-weight: 600;
                color: #00a5ff;
                text-align: center;
            }
            /* Preset Thumbnails */
            .qt-preset-thumbnails {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 10px;
                margin-top: 12px;
                padding: 12px;
                background: rgba(0, 0, 0, 0.2);
                border-radius: 10px;
            }
            .qt-thumb {
                cursor: pointer;
                border-radius: 8px;
                overflow: hidden;
                transition: transform 0.15s ease, box-shadow 0.15s ease;
                background: rgba(255, 255, 255, 0.05);
            }
            .qt-thumb:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            }
            .qt-thumb.active {
                box-shadow: 0 0 0 3px #00a5ff, 0 4px 12px rgba(0, 165, 255, 0.4);
            }
            .qt-thumb-img {
                width: 100%;
                aspect-ratio: 16 / 9;
                background-size: cover;
                background-position: center;
                background-color: rgba(255, 255, 255, 0.08);
            }
            .qt-thumb-placeholder {
                display: flex;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, rgba(0, 165, 255, 0.2) 0%, rgba(26, 77, 232, 0.2) 100%);
                border: 2px dashed rgba(0, 165, 255, 0.4);
            }
            .qt-thumb-placeholder span {
                font-size: 11px;
                color: rgba(255, 255, 255, 0.6);
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            .qt-thumb-current.has-image .qt-thumb-placeholder {
                border: none;
            }
            .qt-thumb-current.has-image .qt-thumb-placeholder span {
                display: none;
            }
            .qt-thumb-label {
                display: block;
                padding: 6px 8px;
                font-size: 11px;
                color: rgba(255, 255, 255, 0.7);
                text-align: center;
                background: rgba(0, 0, 0, 0.3);
            }
            .qt-thumb.active .qt-thumb-label {
                background: rgba(0, 165, 255, 0.3);
                color: #fff;
                font-weight: 600;
            }
            /* Compact preset layout for banner (4 columns) */
            .qt-preset-compact {
                grid-template-columns: repeat(2, 1fr);
                max-width: 280px;
            }
            .qt-thumb-default {
                position: relative;
            }
            .qt-thumb-default::after {
                content: '↩';
                position: absolute;
                top: 6px;
                right: 6px;
                width: 20px;
                height: 20px;
                background: rgba(0, 0, 0, 0.6);
                border-radius: 4px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 12px;
                color: rgba(255, 255, 255, 0.8);
                opacity: 0;
                transition: opacity 0.15s ease;
            }
            .qt-thumb-default:hover::after {
                opacity: 1;
            }
            /* Service Images - Single Row Layout */
            .qt-service-row {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px 16px !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            }
            .qt-service-row:last-child {
                border-bottom: none;
            }
            .qt-service-label {
                min-width: 110px;
                flex-shrink: 0;
            }
            .qt-service-label strong {
                font-size: 13px;
                color: rgba(255, 255, 255, 0.9);
            }
            .qt-service-inputs {
                flex: 1;
            }
            .qt-service-inputs .input-with-button {
                margin: 0;
            }
            .qt-service-thumbs {
                display: flex;
                gap: 8px;
                flex-shrink: 0;
            }
            .qt-thumb-inline {
                width: 50px;
                height: 50px;
                border-radius: 6px;
                overflow: hidden;
                cursor: pointer;
                transition: transform 0.15s ease, box-shadow 0.15s ease;
                background: rgba(255, 255, 255, 0.05);
            }
            .qt-thumb-inline:hover {
                transform: scale(1.08);
            }
            .qt-thumb-inline.active {
                box-shadow: 0 0 0 2px #00a5ff;
            }
            .qt-thumb-img-inline {
                width: 100%;
                height: 100%;
                background-size: cover;
                background-position: center;
            }
            .qt-thumb-placeholder-inline {
                display: flex;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, rgba(0, 165, 255, 0.15) 0%, rgba(26, 77, 232, 0.15) 100%);
                border: 1px dashed rgba(0, 165, 255, 0.4);
            }
            .qt-thumb-placeholder-inline span {
                font-size: 16px;
                color: rgba(255, 255, 255, 0.4);
            }
            .qt-thumb-inline.has-image .qt-thumb-placeholder-inline {
                border: none;
            }
            .qt-thumb-inline.has-image .qt-thumb-placeholder-inline span {
                display: none;
            }
            .qt-thumb-inline.qt-thumb-preset {
                position: relative;
            }
            .qt-thumb-inline.qt-thumb-preset::after {
                content: '↩';
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 24px;
                height: 24px;
                background: rgba(0, 0, 0, 0.7);
                border-radius: 4px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 12px;
                color: #fff;
                opacity: 0;
                transition: opacity 0.15s ease;
            }
            .qt-thumb-inline.qt-thumb-preset:hover::after {
                opacity: 1;
            }
            .qt-actions {
                margin-top: 18px;
                display: flex;
                gap: 12px;
                flex-wrap: wrap;
            }
            .qt-capture-status {
                margin-top: 16px;
                padding: 16px;
                background: rgba(33, 150, 243, 0.15);
                border: 1px solid rgba(33, 150, 243, 0.4);
                border-radius: 12px;
                color: #90caf9;
            }
            .capture-progress {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .capture-spinner {
                width: 20px;
                height: 20px;
                border: 3px solid rgba(144, 202, 249, 0.3);
                border-top-color: #90caf9;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
            .qt-results {
                margin-top: 18px;
                padding: 16px;
                border-radius: 12px;
                display: none;
            }
            .qt-results.success {
                display: block;
                background: rgba(76, 175, 80, 0.15);
                border: 1px solid rgba(76, 175, 80, 0.4);
                color: #b9f5c8;
            }
            .qt-results.error {
                display: block;
                background: rgba(244, 67, 54, 0.15);
                border: 1px solid rgba(244, 67, 54, 0.4);
                color: #ffb4b4;
            }
            @media (max-width: 768px) {
                .qt-tabs {
                    justify-content: center;
                }
                .qt-actions {
                    flex-direction: column;
                }
            }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            let mediaFrame;
            const previewUrls = <?php echo wp_json_encode($preview_urls); ?>;
            // Industry to page class mapping
            const industryPageClasses = <?php echo wp_json_encode($industry_page_classes); ?>;
            // Default logo URLs from PHP constants
            const DEFAULT_HEADER_LOGO = '<?php echo esc_js(self::DEFAULT_HEADER_LOGO); ?>';
            const DEFAULT_FOOTER_LOGO = '<?php echo esc_js(self::DEFAULT_FOOTER_LOGO); ?>';
            
            // Default slider values
            const DEFAULT_HEADER_WIDTH = 79;
            const DEFAULT_BANNER_WIDTH = 55;
            const tabLabels = <?php echo wp_json_encode($tabs); ?>;
            const savedAssets = <?php echo wp_json_encode($saved_assets); ?>;
            const TAB_STORAGE_KEY = 'bluzetta_active_tab';
            
            // Populate input fields with saved values on page load
            function loadSavedAssets() {
                console.log('loadSavedAssets: Starting... savedAssets=', savedAssets);
                
                if (!savedAssets || Object.keys(savedAssets).length === 0) {
                    console.log('loadSavedAssets: No saved assets found');
                    return;
                }

                // Get active industry from localStorage or default
                const activeIndustry = localStorage.getItem(TAB_STORAGE_KEY) || 'roofing';

                
                $('.qt-tab-panel').each(function() {
                    const industry = $(this).data('industry');
                    if (industry !== activeIndustry) return; // Skip non-active industries
                                    
                    $(this).find('.qt-target-row').each(function() {
                        const $row = $(this);
                        const key = $row.data('key');
                        const savedKey = industry + '_' + key;
                        const saved = savedAssets[savedKey];
                        
                        console.log('loadSavedAssets: Checking', savedKey, '=', saved);
                        
                        if (saved && saved.url) {
                            const $input = $row.find('.new-image-url');
                            $input.val(saved.url);
                            console.log('loadSavedAssets: Set input value for', savedKey);
                            
                            // Update current thumbnail to show saved image
                            const $currentThumb = $row.find('.qt-thumb-current');
                            if ($currentThumb.length) {
                                $currentThumb.addClass('has-image');
                                $currentThumb.find('.qt-thumb-img, .qt-thumb-img-inline').css('background-image', 'url("' + saved.url + '")');
                            }
                            
                            // Load saved widths into sliders
                            if (saved.widths && saved.widths.length) {
                                saved.widths.forEach(function(w) {
                                    const $slider = $row.find('.width-slider[data-width-selector="' + w.selector + '"]');
                                    if ($slider.length) {
                                        const numVal = parseInt(w.value) || 50;
                                        $slider.val(numVal);
                                        $slider.closest('.qt-slider-wrap').find('.qt-slider-value').text(numVal + '%');
                                    }
                                });
                            }
                        }
                    });
                });
            }
            
            // Load saved assets on page load
            console.log('Page loaded, calling loadSavedAssets...');
            loadSavedAssets();
            

            function clearAllInputs() {
                $('.qt-tab-panel .new-image-url').val('');
                $('.qt-thumb-current').removeClass('has-image');
                $('.qt-thumb-current .qt-thumb-img, .qt-thumb-current .qt-thumb-img-inline').css('background-image', '');
                $('.qt-thumb, .qt-thumb-inline').removeClass('active');
                $('.qt-thumb-current').addClass('active');
            }

            // Calculate and set preview scale to fit container width exactly
            function updatePreviewScale() {
                const section = document.querySelector('.qt-preview-section-inner');
                const wrap = document.querySelector('.qt-preview-iframe-wrap');
                if (!section || !wrap) return;
                
                const containerWidth = section.offsetWidth;
                const iframeWidth = 1440;
                const iframeHeight = 900;
                const scale = containerWidth / iframeWidth;
                
                wrap.style.transform = 'scale(' + scale + ')';
                section.style.height = (iframeHeight * scale) + 'px';
            }
            
            // Run on load and resize
            updatePreviewScale();
            $(window).on('resize', updatePreviewScale);

            function openMediaLibrary(callback) {
                if (typeof wp === 'undefined' || !wp.media) {
                    return;
                }
                if (mediaFrame) {
                    mediaFrame.off('select');
                }
                mediaFrame = wp.media({
                    title: 'Select Image',
                    library: { type: 'image' },
                    button: { text: 'Use this image' },
                    multiple: false
                });

                mediaFrame.on('select', function() {
                    const attachment = mediaFrame.state().get('selection').first().toJSON();
                    if (attachment && attachment.url && typeof callback === 'function') {
                        callback(attachment);
                    }
                });

                mediaFrame.open();
            }

            function updatePreviewIframe(panelId) {
                const url = previewUrls[panelId] || '';
                const label = tabLabels[panelId] || 'Preview';
                $('.qt-preview-tab-label').text(label);
                if (url) {
                    $('#qt-preview-empty').hide();
                    $('.qt-preview-section-inner').show();
                    $('#qt-preview-iframe').attr('src', url);
                } else {
                    $('.qt-preview-section-inner').hide();
                    $('#qt-preview-empty').show();
                }
            }

            function setActiveTab(panelId) {
                if (!panelId) return;
                $('.qt-tab').removeClass('active').attr('aria-selected', 'false');
                $('.qt-tab-panel').removeClass('active');
                $(`.qt-tab[data-panel="${panelId}"]`).addClass('active').attr('aria-selected', 'true');
                $(`#panel-${panelId}`).addClass('active');
                updatePreviewIframe(panelId);
                setTimeout(updatePreviewScale, 100);
            }

            $('.qt-tab').on('click', function() {
                const panelId = $(this).data('panel');
                setActiveTab(panelId);
            });

            setActiveTab($('.qt-tab.active').data('panel') || Object.keys(previewUrls)[0]);
            
            // Restore last active tab from localStorage
            const storedTab = localStorage.getItem(TAB_STORAGE_KEY);
            if (storedTab && previewUrls[storedTab] !== undefined) {
                setActiveTab(storedTab);
            }
            
            // Persist active tab on click
            $('.qt-tab').on('click', function() {
                const panelId = $(this).data('panel');
                setActiveTab(panelId);
                localStorage.setItem(TAB_STORAGE_KEY, panelId);
                clearAllInputs(); // New function
                loadSavedAssets(); // Will now only load active industry
                autoSave(true); // Saves active, clears others
            });

            $(document).on('click', '.select-media-button', function() {
                const $input = $(this).closest('.input-with-button').find('input[type="text"]');
                openMediaLibrary(function(attachment) {
                    $input.val(attachment.url).trigger('input');
                    // Update current thumbnail
                    updateCurrentThumbnail($input);
                    // Trigger auto-save after media selection
                    scheduleAutoSave(true);
                });
            });
            
            // Update current thumbnail preview when URL changes
            function updateCurrentThumbnail($input) {
                const url = $input.val().trim();
                const $row = $input.closest('.qt-target-row');
                const $currentThumb = $row.find('.qt-thumb-current');
                
                if ($currentThumb.length && url) {
                    $currentThumb.addClass('has-image');
                    // Handle both regular and inline thumbnail image containers
                    $currentThumb.find('.qt-thumb-img, .qt-thumb-img-inline').css('background-image', 'url("' + url + '")');
                    // Set this thumbnail as active (handle both classes)
                    $row.find('.qt-thumb, .qt-thumb-inline').removeClass('active');
                    $currentThumb.addClass('active');
                } else if ($currentThumb.length) {
                    $currentThumb.removeClass('has-image');
                    $currentThumb.find('.qt-thumb-img, .qt-thumb-img-inline').css('background-image', '');
                }
            }
            
            // Handle URL input changes to update thumbnail
            $(document).on('input', '.new-image-url', function() {
                updateCurrentThumbnail($(this));
            });
            
            // Handle preset thumbnail clicks (both regular and inline)
            $(document).on('click', '.qt-thumb-preset', function() {
                const presetUrl = $(this).data('preset');
                const $row = $(this).closest('.qt-target-row');
                const $input = $row.find('.new-image-url');
                const key = $row.data('key');
                
                console.log('Preset clicked:', key, 'URL:', presetUrl);
                
                if (presetUrl) {
                    $input.val(presetUrl);
                    console.log('Input value set to:', $input.val());
                    
                    // Update active state (handle both classes)
                    $row.find('.qt-thumb, .qt-thumb-inline').removeClass('active');
                    $(this).addClass('active');
                    
                    // Also update current thumbnail preview
                    const $currentThumb = $row.find('.qt-thumb-current');
                    $currentThumb.addClass('has-image');
                    $currentThumb.find('.qt-thumb-img, .qt-thumb-img-inline').css('background-image', 'url("' + presetUrl + '")');
                    
                    // Trigger auto-save immediately (not debounced)
                    console.log('Triggering immediate save...');
                    autoSave(true);
                }
            });
            
            // Handle click on current thumbnail (clears selection)
            $(document).on('click', '.qt-thumb-current', function() {
                const $row = $(this).closest('.qt-target-row');
                $row.find('.qt-thumb, .qt-thumb-inline').removeClass('active');
                $(this).addClass('active');
            });

            const GLOBAL_COLOR_VARS = {
                dark: ['--e-global-color-6', '--e-global-color-15d0d07', '--e-global-color-secondary'],
                light: ['--e-global-color-4', '--e-global-color-d03c845', '--e-global-color-primary']
            };

            function updatePreviewColors() {
                const darkColor = $('#dark-global-color').val().trim() || '#05112f';
                const lightColor = $('#light-global-color').val().trim() || '#f5f6fb';
                
                // Update admin page (for any local previews)
                GLOBAL_COLOR_VARS.dark.forEach(varName => document.documentElement.style.setProperty(varName, darkColor, 'important'));
                GLOBAL_COLOR_VARS.light.forEach(varName => document.documentElement.style.setProperty(varName, lightColor, 'important'));
                
                // Update iframe preview in real-time via postMessage
                const iframe = document.getElementById('qt-preview-iframe');
                if (iframe && iframe.contentWindow) {
                    iframe.contentWindow.postMessage({
                        type: 'bluzetta_color_preview',
                        colors: {
                            dark: darkColor,
                            light: lightColor
                        }
                    }, '*');
                }
            }

            function syncColorInputs(textSelector, pickerSelector) {
                $(textSelector).on('input', function() {
                    $(pickerSelector).val($(this).val());
                    updatePreviewColors();
                });
                $(pickerSelector).on('input', function() {
                    $(textSelector).val($(this).val());
                    updatePreviewColors();
                });
            }

            syncColorInputs('#dark-global-color', '#dark-global-color-picker');
            syncColorInputs('#light-global-color', '#light-global-color-picker');
            
            // Update colors when iframe loads
            $('#qt-preview-iframe').on('load', function() {
                setTimeout(updatePreviewColors, 500);
            });
            
            updatePreviewColors();
            
            // Auto-save functionality
            let autoSaveTimeout = null;
            let isSaving = false;
            
            function showAutoSaveStatus(message, isError) {
                const $status = $('#swapper-results');
                $status.removeClass('error success');
                if (isError) {
                    $status.addClass('error').html('❌ ' + message);
                } else {
                    $status.addClass('success').html('✅ ' + message);
                }
                // Auto-hide success messages after 3 seconds
                if (!isError) {
                    setTimeout(() => {
                        $status.removeClass('success').html('');
                    }, 3000);
                }
            }
            
            function autoSave(refreshIframe = true) {
                if (isSaving) {
                    console.log('autoSave: Already saving, skipping');
                    return;
                }
                
                const data = collectData();
                
                // Check if there's anything to save
                const hasAssets = Object.keys(data.industryAssets).length > 0;
                const hasColors = data.colors.darkColor || data.colors.lightColor;
                
                console.log('autoSave: hasAssets=', hasAssets, 'hasColors=', hasColors);
                console.log('autoSave: Full data=', JSON.stringify(data, null, 2));
                
                if (!hasAssets && !hasColors) {
                    console.log('autoSave: Nothing to save');
                    return;
                }
                
                isSaving = true;
                showAutoSaveStatus('Saving...', false);
                
                $.ajax({
                    url: swapperAjax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'apply_template_changes',
                        nonce: swapperAjax.nonce,
                        changes: JSON.stringify(data)
                    },
                    success: function(response) {
                        isSaving = false;
                        console.log('autoSave: AJAX response=', response);
                        if (response.success) {
                            showAutoSaveStatus('Auto-saved!', false);
                            console.log('autoSave: Success! Saved script length:', response.data.script ? response.data.script.length : 0);
                            if (refreshIframe) {
                                const iframe = document.getElementById('qt-preview-iframe');
                                if (iframe && iframe.src) {
                                    iframe.src = iframe.src;
                                }
                            }
                        } else {
                            console.log('autoSave: Server error:', response.data.message);
                            showAutoSaveStatus(response.data.message, true);
                        }
                    },
                    error: function(xhr, status, error) {
                        isSaving = false;
                        console.log('autoSave: AJAX error:', status, error);
                        showAutoSaveStatus('Auto-save failed. Please try again.', true);
                    }
                });
            }
            
            function scheduleAutoSave(refreshIframe = true) {
                if (autoSaveTimeout) {
                    clearTimeout(autoSaveTimeout);
                }
                autoSaveTimeout = setTimeout(() => autoSave(refreshIframe), 500);
            }
            
            // Auto-save on blur for all inputs
            $(document).on('blur', '.new-image-url', function() {
                scheduleAutoSave(true);
            });
            
            // Slider live update and auto-save on release
            $(document).on('input', '.width-slider', function() {
                const val = $(this).val();
                $(this).closest('.qt-slider-wrap').find('.qt-slider-value').text(val + '%');
            });
            
            $(document).on('change', '.width-slider', function() {
                scheduleAutoSave(true);
            });
            
            // Auto-save on color picker change (blur)
            $('#dark-global-color, #light-global-color').on('blur', function() {
                scheduleAutoSave(true);
            });
            
            // Auto-save on color picker close (change event fires when picker closes)
            $('#dark-global-color-picker, #light-global-color-picker').on('change', function() {
                scheduleAutoSave(true);
            });

            $('#preview-changes').on('click', function() {
                const data = collectData();
                console.log('Preview Data:', data);
                alert('Preview logged to console.');
            });
            
            $('#apply-changes').on('click', function() {
                const $btn = $(this);
                const originalText = $btn.text();
                $btn.prop('disabled', true).text('⏳ Applying...');
                
                const data = collectData();
                
                $.ajax({
                    url: swapperAjax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'apply_template_changes',
                        nonce: swapperAjax.nonce,
                        changes: JSON.stringify(data)
                    },
                    success: function(response) {
                        $btn.prop('disabled', false).text(originalText);
                        $('#swapper-results').removeClass('error success');
                        if (response.success) {
                            $('#swapper-results')
                                .addClass('success')
                                .html('✅ ' + response.data.message);
                            // Reload the preview iframe to show updated colors
                            const iframe = document.getElementById('qt-preview-iframe');
                            if (iframe && iframe.src) {
                                iframe.src = iframe.src;
                            }
                        } else {
                            $('#swapper-results')
                                .addClass('error')
                                .html('❌ ' + response.data.message);
                        }
                    },
                    error: function() {
                        $btn.prop('disabled', false).text(originalText);
                        $('#swapper-results')
                            .removeClass('success')
                            .addClass('error')
                            .html('❌ Network error. Please try again.');
                    }
                });
            });
            
            function collectData() {
                const industryAssets = {};

                $('.qt-tab-panel').each(function() {
                    const industry = $(this).data('industry');
                    const assets = [];

                    $(this).find('.qt-target-row').each(function() {
                        const $row = $(this);
                        const key = $row.data('key') || '';
                        const selectors = $row.data('selectors') || [];
                        const $input = $row.find('.new-image-url');
                        const url = $input.val() ? $input.val().trim() : '';
                        const assetType = $row.data('type') || 'default';
                        
                        // Debug logging
                        if (url) {
                            console.log('collectData: Found', key, 'with URL:', url.substring(0, 50) + '...');
                        }
                        
                        if (!url || !selectors.length) {
                            return;
                        }

                        const widths = [];
                        // Collect from sliders
                        $row.find('.width-slider').each(function() {
                            const selector = $(this).data('width-selector');
                            const value = $(this).val();
                            if (selector && value) {
                                widths.push({
                                    selector: selector,
                                    value: value + '%'
                                });
                            }
                        });

                        assets.push({
                            key: key,
                            selectors: selectors,
                            url: url,
                            widths: widths,
                            type: assetType
                        });
                    });

                    if (industry && assets.length) {
                        industryAssets[industry] = assets;
                        console.log('collectData: Industry', industry, 'has', assets.length, 'assets');
                    }
                });
                
                const result = {
                    industryAssets: industryAssets,
                    colors: {
                        darkColor: $('#dark-global-color').val().trim(),
                        lightColor: $('#light-global-color').val().trim()
                    },
                    pageId: '',
                    activeIndustry: localStorage.getItem(TAB_STORAGE_KEY) || 'roofing'
                };
                
                console.log('collectData: Total assets collected:', Object.keys(industryAssets).reduce((sum, k) => sum + industryAssets[k].length, 0));
                
                return result;
            }
            
            // Capture screenshots and video (server-side, no permissions)
            let currentCaptureResults = [];

            // Button: Start capture (server-side)
            document.getElementById('capture-assets').addEventListener('click', function() {
                const $btn = $('#capture-assets');
                const originalText = $btn.html();
                const industry = $('.qt-tab-panel.active').data('industry');
                const previewUrl = previewUrls[industry];
                const clientName = $('#capture-client-name').val().trim() || industry;
                
                if (!previewUrl) {
                    alert('No preview URL for this industry');
                    return;
                }
                
                $btn.prop('disabled', true).html('📸 Capturing...');
                $('#capture-status').show().find('.capture-text').text('Starting capture...');
                runServerCapture(previewUrl, clientName, industry, $btn, originalText);
            });

            function postCapture(payload) {
                return $.ajax({
                    url: swapperAjax.ajax_url,
                    method: 'POST',
                    dataType: 'json',
                    data: Object.assign({ nonce: swapperAjax.nonce }, payload)
                });
            }

            function openCaptureModal(results) {
                const $modal = $('#capture-review-modal');
                const $grid = $modal.find('.qt-capture-grid');
                $grid.empty();
                
                results.forEach(item => {
                    const $item = $('<div class="qt-capture-item"></div>');
                    const $thumb = $('<div class="qt-capture-thumb"></div>');
                    if (item.type === 'video') {
                        $thumb.append('<video controls src="' + item.url + '"></video>');
                    } else {
                        $thumb.append('<img src="' + item.url + '" alt="">');
                    }
                    $item.append($thumb);
                    $item.append('<span>' + item.filename + '</span>');
                    $grid.append($item);
                });
                
                $modal.addClass('active').show();
            }

            function closeCaptureModal() {
                $('#capture-review-modal').removeClass('active').hide();
            }

            async function deleteCapturedFiles(files) {
                for (const file of files) {
                    if (!file || !file.filename) continue;
                    await postCapture({
                        action: 'delete_captured_file',
                        filename: file.filename
                    });
                }
            }

            async function rejectCaptureReview() {
                if (currentCaptureResults.length) {
                    await deleteCapturedFiles(currentCaptureResults);
                }
                closeCaptureModal();
                currentCaptureResults = [];
                $('#swapper-results').removeClass('success').addClass('error').html('❌ Captures deleted.');
            }

            $(document).on('click', '.qt-reject-captures, .qt-modal-close, .qt-modal-backdrop', async function() {
                await rejectCaptureReview();
            });

            $(document).on('keydown', function(e) {
                if (e.key === 'Escape' && $('#capture-review-modal').hasClass('active')) {
                    rejectCaptureReview();
                }
            });

            $(document).on('click', '.qt-approve-captures', function() {
                closeCaptureModal();
                currentCaptureResults = [];
                $('#swapper-results').removeClass('error').addClass('success').html('✅ Captures approved.');
            });

            async function captureViaServer(options) {
                const payload = Object.assign({ action: 'upload_captured_screenshot' }, options);
                const resp = await postCapture(payload);
                if (!resp || !resp.success) {
                    throw new Error((resp && resp.data) ? resp.data : 'Screenshot failed');
                }
                currentCaptureResults.push({
                    url: resp.data.url,
                    filename: resp.data.filename,
                    type: 'image'
                });
                return resp.data;
            }

            async function captureVideoViaServer(options) {
                const payload = Object.assign({ action: 'capture_scroll_video' }, options);
                const resp = await postCapture(payload);
                if (!resp || !resp.success) {
                    throw new Error((resp && resp.data) ? resp.data : 'Video failed');
                }
                currentCaptureResults.push({
                    url: resp.data.url,
                    filename: resp.data.filename,
                    type: 'video'
                });
                return resp.data;
            }

            async function runServerCapture(previewUrl, clientName, industry, $btn, originalText) {
                try {
                    currentCaptureResults = [];
                    await delay(1000);
                    
                    // Screenshot 1: Desktop viewport
                    $('#capture-status').find('.capture-text').text('Capturing desktop viewport...');
                    await captureViaServer({
                        url: previewUrl,
                        filename: clientName + '-desktop-viewport.png',
                        width: 1440,
                        height: 900,
                        scrollY: 0,
                        fullPage: false,
                        wait: 2000
                    });
                    
                    const massageTemplateIndustries = ['fitness', 'salon', 'barber', 'spa', 'aesthetician', 'nails', 'makeup', 'massage'];
                    const skipMiddle = massageTemplateIndustries.indexOf(industry) !== -1;
                    
                    if (!skipMiddle) {
                        // Screenshot 2: Scroll down and capture middle section
                        $('#capture-status').find('.capture-text').text('Capturing page middle...');
                        await captureViaServer({
                            url: previewUrl,
                            filename: clientName + '-desktop-middle.png',
                            width: 1440,
                            height: 900,
                            scrollY: 900,
                            fullPage: false,
                            wait: 2000
                        });
                    }
                    
                    // Screenshot 3: Mobile
                    $('#capture-status').find('.capture-text').text('Capturing mobile view...');
                    await captureViaServer({
                        url: previewUrl,
                        filename: clientName + '-mobile-viewport.png',
                        width: 375,
                        height: 812,
                        scrollY: 0,
                        fullPage: false,
                        wait: 2000
                    });
                    
                    // Video: 11-second scroll recording
                    $('#capture-status').find('.capture-text').text('Recording scroll video (11s)...');
                    await captureVideoViaServer({
                        url: previewUrl,
                        filename: clientName + '-scroll-video.mp4',
                        width: 1440,
                        height: 900,
                        duration: 11000,
                        wait: 2000
                    });
                    
                    // Specific page captures
                    const constructionIndustries = ['roofing', 'tradesmen', 'builders', 'landscaping', 'realestate', 'motors'];
                    const isConstruction = constructionIndustries.indexOf(industry) !== -1;
                    await captureSpecificSectionsServer(previewUrl, isConstruction, clientName);
                    
                    $('#capture-status').hide();
                    $btn.prop('disabled', false).html(originalText);
                    $('#swapper-results').removeClass('error').addClass('success').html('✅ Captures ready for review.');
                    openCaptureModal(currentCaptureResults);
                    
                } catch (err) {
                    console.error('Capture error:', err);
                    if (currentCaptureResults.length) {
                        await deleteCapturedFiles(currentCaptureResults);
                    }
                    currentCaptureResults = [];
                    $('#capture-status').hide();
                    $btn.prop('disabled', false).html(originalText);
                    $('#swapper-results').removeClass('success').addClass('error').html('❌ Capture failed: ' + err.message);
                }
            }

            function delay(ms) {
                return new Promise(r => setTimeout(r, ms));
            }

            async function captureSpecificSectionsServer(previewUrl, isConstruction, clientName) {
                if (isConstruction) {
                    // Construction: click button on template page, then go to reservations
                    $('#capture-status').find('.capture-text').text('Capturing template after click...');
                    await captureViaServer({
                        url: previewUrl,
                        filename: clientName + '-template-after-click.png',
                        width: 1440,
                        height: 900,
                        scrollY: 0,
                        clickSelector: '.elementor-element-XXXXX button',
                        wait: 3000
                    });
                    
                    // Reservations page
                    $('#capture-status').find('.capture-text').text('Loading reservations page...');
                    await captureViaServer({
                        url: '<?php echo home_url("/reservations/"); ?>',
                        filename: clientName + '-reservations-page.png',
                        width: 1440,
                        height: 900,
                        scrollY: 0,
                        wait: 3000
                    });
                    
                } else {
                    // Beauty: scroll to products, screenshot, click, screenshot
                    $('#capture-status').find('.capture-text').text('Capturing products section...');
                    await captureViaServer({
                        url: previewUrl,
                        filename: clientName + '-products-before.png',
                        width: 1440,
                        height: 900,
                        scrollToSelector: '.elementor-element-db261b6 .elementskit-section-title-wraper .elementskit-section-title',
                        wait: 3000
                    });
                    
                    await captureViaServer({
                        url: previewUrl,
                        filename: clientName + '-products-after.png',
                        width: 1440,
                        height: 900,
                        scrollToSelector: '.elementor-element-db261b6 .elementskit-section-title-wraper .elementskit-section-title',
                        clickSelector: 'div.bluzetta-product-card:nth-child(1) > div:nth-child(2) > button:nth-child(4)',
                        wait: 3000
                    });
                }
            }
            // Reset to Defaults button handler
            $(document).on('click', '.qt-reset-card', function() {
                var $btn = $(this);
                var industry = $('.qt-tab-panel.active').data('industry');
                var $panel = $('.qt-tab-panel.active');
                
                console.log('========================================');
                console.log('RESET STARTED for industry:', industry);
                console.log('========================================');
                
                // 1. Reset ALL rows - both presets AND logos
                console.log('--- Resetting All Rows ---');
                var resetCount = 0;
                
                $panel.find('.qt-target-row').each(function() {
                    var $row = $(this);
                    var key = $row.data('key');
                    var $input = $row.find('.new-image-url');
                    
                    console.log('Processing row:', key);
                    
                    // CASE 1: Header/Banner Logo - reset to DEFAULT_HEADER_LOGO
                    if (key === 'header_banner_logo') {
                        $input.val(DEFAULT_HEADER_LOGO);
                        updateCurrentThumbnail($input);
                        console.log('✓ Reset header_banner_logo to:', DEFAULT_HEADER_LOGO);
                        resetCount++;
                        return; // Skip to next row
                    }
                    
                    // CASE 2: Footer Logo - reset to DEFAULT_FOOTER_LOGO
                    if (key === 'footer_logo') {
                        $input.val(DEFAULT_FOOTER_LOGO);
                        updateCurrentThumbnail($input);
                        console.log('✓ Reset footer_logo to:', DEFAULT_FOOTER_LOGO);
                        resetCount++;
                        return; // Skip to next row
                    }
                    
                    // CASE 3: All other rows - reset to first preset
                    var $firstPreset = $row.find('.qt-thumb-preset').first();
                    
                    // If no regular preset, try inline preset
                    if (!$firstPreset.length) {
                        $firstPreset = $row.find('.qt-thumb-inline.qt-thumb-preset').first();
                    }
                    
                    if ($firstPreset.length) {
                        var presetUrl = $firstPreset.data('preset');
                        
                        if (presetUrl) {
                            // Set input value
                            $input.val(presetUrl);
                            
                            // Update active state on ALL thumbnails
                            $row.find('.qt-thumb, .qt-thumb-inline').removeClass('active');
                            $firstPreset.addClass('active');
                            
                            // Update current thumbnail (regular)
                            var $currentThumb = $row.find('.qt-thumb-current');
                            if ($currentThumb.length) {
                                $currentThumb.addClass('has-image');
                                $currentThumb.find('.qt-thumb-img').css('background-image', 'url("' + presetUrl + '")');
                            }
                            
                            // Update current thumbnail (inline)
                            var $currentInline = $row.find('.qt-thumb-inline.qt-thumb-current');
                            if ($currentInline.length) {
                                $currentInline.addClass('has-image');
                                $currentInline.find('.qt-thumb-img-inline').css('background-image', 'url("' + presetUrl + '")');
                            }
                            
                            resetCount++;
                            console.log('✓ Reset', key, 'to first preset');
                        }
                    } else {
                        console.log('⚠ No preset found for:', key);
                    }
                });
                
                console.log('Total rows reset:', resetCount);
                
                // 2. Reset width sliders to defaults
                console.log('--- Resetting Sliders ---');
                var sliderCount = 0;
                
                $panel.find('.width-slider').each(function() {
                    var $slider = $(this);
                    var selector = $slider.data('width-selector');
                    var defaultVal = DEFAULT_HEADER_WIDTH;
                    
                    // Check if it's a banner/footer slider
                    if (selector) {
                        var selectorLower = selector.toLowerCase();
                        if (selectorLower.includes('171f48a') || 
                            selectorLower.includes('f04471d') || 
                            selectorLower.includes('banner') || 
                            selectorLower.includes('footer')) {
                            defaultVal = DEFAULT_BANNER_WIDTH;
                        }
                    }
                    
                    $slider.val(defaultVal);
                    $slider.closest('.qt-slider-wrap').find('.qt-slider-value').text(defaultVal + '%');
                    sliderCount++;
                    console.log('✓ Reset slider:', selector, 'to', defaultVal + '%');
                });
                
                console.log('Total sliders reset:', sliderCount);
                
                // 3. Visual feedback
                var originalText = $btn.html();
                $btn.html('✅ Resetting...').prop('disabled', true);
                
                // 4. Trigger auto-save
                console.log('--- Triggering Auto-save ---');
                autoSave(true);
                
                // 5. Force preview refresh after save completes
                setTimeout(function() {
                    const iframe = document.getElementById('qt-preview-iframe');
                    if (iframe && iframe.src) {
                        console.log('✓ Reloading preview iframe...');
                        iframe.src = iframe.src; // Force reload
                    }
                    
                    // Re-enable button
                    $btn.html('✅ Reset Complete!');
                    setTimeout(function() {
                        $btn.html(originalText).prop('disabled', false);
                    }, 1500);
                }, 1500);
                
                console.log('========================================');
                console.log('RESET COMPLETE for:', industry);
                console.log('========================================');
            });
        });
        </script>
        <?php
    }
    
    public function apply_changes() {
        check_ajax_referer('swapper_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $changes = json_decode(stripslashes($_POST['changes'] ?? ''), true);
        $industryAssets = $changes['industryAssets'] ?? [];
        $activeIndustry = sanitize_text_field($changes['activeIndustry'] ?? 'roofing');

        $assets = [];
        foreach ($industryAssets as $industry => $items) {
            if (!is_array($items)) {
                continue;
            }

            if ($industry !== $activeIndustry) {
                continue; // Only keep assets for the active industry/tab
            }

            foreach ($items as $item) {
                $url = sanitize_text_field($item['url'] ?? '');
                $selectors = array_filter(array_map('sanitize_text_field', (array) ($item['selectors'] ?? [])));
                if (!$url || empty($selectors)) {
                    continue;
                }

                $widths = [];
                foreach ((array) ($item['widths'] ?? []) as $width) {
                    $selector = sanitize_text_field($width['selector'] ?? '');
                    $value = sanitize_text_field($width['value'] ?? '');
                    if ($selector && $value) {
                        $widths[] = [
                            'selector' => $selector,
                            'value' => $value
                        ];
                    }
                }

                $assets[] = [
                    'industry' => sanitize_text_field($industry),
                    'key' => sanitize_text_field($item['key'] ?? ''),
                    'url' => $url,
                    'selectors' => $selectors,
                    'widths' => $widths,
                    'type' => sanitize_text_field($item['type'] ?? 'default')
                ];
            }
        }

        $payload = [
            'assets' => $assets,
            'colors' => [
                'dark' => sanitize_text_field($changes['colors']['darkColor'] ?? ''),
                'light' => sanitize_text_field($changes['colors']['lightColor'] ?? '')
            ],
            'activeIndustry' => $activeIndustry
        ];

        // Update Elementor kit colors directly
        $colors_updated = false;
        if (!empty($payload['colors']['dark'])) {
            $this->update_elementor_color('15d0d07', $payload['colors']['dark']);
            $colors_updated = true;
        }
        if (!empty($payload['colors']['light'])) {
            $this->update_elementor_color('d03c845', $payload['colors']['light']);
            $colors_updated = true;
        }
        
        // Also keep a backup in our option
        update_option('template_swapper_colors', $payload['colors']);
        
        $saved_assets = [];
        // Only save assets for the active industry - others get cleared
        foreach ($assets as $asset) {
            if ($asset['industry'] !== $activeIndustry) continue;
            $key = $asset['industry'] . '_' . $asset['key'];
            $saved_assets[$key] = [
                'url' => $asset['url'],
                'widths' => $asset['widths'] ?? [],
                'selectors' => $asset['selectors'] ?? [],
                'type' => $asset['type'] ?? 'default',
                'industry' => $asset['industry'] ?? ''
            ];
        }
        update_option('template_swapper_saved_assets', $saved_assets);
        update_option('template_swapper_active_industry', $activeIndustry);

        // Rebuild payload with ALL saved assets from ALL industries
        $all_saved = get_option('template_swapper_saved_assets', []);
        $all_assets = [];
        foreach ($all_saved as $key => $saved) {
            $all_assets[] = [
                'industry' => $saved['industry'] ?? '',
                'key' => explode('_', $key, 2)[1] ?? '',
                'url' => $saved['url'] ?? '',
                'selectors' => $saved['selectors'] ?? [],
                'widths' => $saved['widths'] ?? [],
                'type' => $saved['type'] ?? 'default'
            ];
        }

        $full_payload = [
            'assets' => $all_assets,
            'colors' => $payload['colors'],
            'activeIndustry' => $activeIndustry
        ];

        $js_code = $this->generate_swap_script($full_payload);

        update_option('template_swapper_active_script', $js_code);
        update_option('template_swapper_target_page', sanitize_text_field($changes['pageId'] ?? ''));
        
        add_action('wp_footer', function() use ($js_code) {
            echo '<script>' . $js_code . '</script>';
        });
        
        $message = 'Changes applied!';
        if ($colors_updated) {
            $message .= ' Elementor kit colors updated.';
        }
        $message .= ' Refresh your frontend page to see updates.';
        
        wp_send_json_success(array(
            'message' => $message,
            'script' => $js_code,
            'colors_updated' => $colors_updated
        ));
    }
    
    private function generate_swap_script($changes) {

        // Define industry page classes
        $industry_page_classes = [
            'roofing' => 'page-id-5474',
            'tradesmen' => 'page-id-5474',
            'builders' => 'page-id-5474',
            'landscaping' => 'page-id-5474',
            'fitness' => 'page-id-5299',
            'realestate' => 'page-id-5474',
            'motors' => 'page-id-5474',
            'salon' => 'page-id-5299',
            'massage' => 'page-id-5299',
            'barber' => 'page-id-5299',
            'spa' => 'page-id-5299',
            'aesthetician' => 'page-id-5299',
            'nails' => 'page-id-5299',
            'makeup' => 'page-id-5299',
            'restaurants' => 'page-id-0',
            'churches' => 'page-id-0',
            'venues' => 'page-id-0',
        ];
        
        $script = "(function() {\n";
        $activeIndustry = $changes['activeIndustry'] ?? 'roofing';
        $script .= "  function applySwaps() {\n";
        $script .= "    var industryPageMap = " . wp_json_encode($industry_page_classes) . ";\n";
        $script .= "    var bodyClasses = document.body.className || '';\n";
        $script .= "    var activeIndustry = " . wp_json_encode($activeIndustry) . ";\n";
        $script .= "    console.log('Applying industry gates - activeIndustry:', activeIndustry);\n";
        
        // Remove existing gate style if present
        $script .= "    var gateStyle = document.getElementById('bluzetta-industry-gates');\n";
        $script .= "    if (gateStyle) gateStyle.remove();\n";
        $script .= "    gateStyle = document.createElement('style');\n";
        $script .= "    gateStyle.id = 'bluzetta-industry-gates';\n";
        $script .= "    var gateCss = '';\n\n";
        
        // Define industry groups
        $script .= "    var roofingIndustries = ['roofing', 'tradesmen', 'builders', 'landscaping', 'realestate', 'motors', 'restaurants', 'churches'];\n";
        $script .= "    var beautyIndustries = ['salon', 'massage', 'nails', 'spa', 'barber', 'aesthetician', 'makeup', 'fitness', 'venues'];\n\n";
        
        // Check which group the active industry belongs to
        $script .= "    var isRoofingGroup = roofingIndustries.indexOf(activeIndustry) !== -1;\n";
        $script .= "    var isBeautyGroup = beautyIndustries.indexOf(activeIndustry) !== -1;\n\n";
        
        $script .= "    console.log('Industry group - isRoofing:', isRoofingGroup, 'isBeauty:', isBeautyGroup);\n\n";
        
        // Apply gating based on group
        $script .= "    if (isBeautyGroup) {\n";
        $script .= "      console.log('  -> Hiding roofing-specific elements');\n";
        $script .= "      gateCss += '.elementor-5334 .elementor-element.elementor-element-607e38d .elementskit-menu-container{display:none!important;}';\n";
        $script .= "      gateCss += '.elementor-element.elementor-element-691ac29 div.elementor-widget-wrap.elementor-element-populated div.elementor-element.elementor-element-05cdb3a.elementor-align-center.elementor-widget.elementor-widget-elementskit-button{display:none!important;}';\n";
        $script .= "      gateCss += '.elementor-5334 .elementor-element.elementor-element-83698d9{display:none!important;}';\n";
        $script .= "      gateCss += '.elementor-5352 .elementor-element.elementor-element-9309fdb:not(.elementor-motion-effects-element-type-background){display:none!important;}';\n";
        $script .= "    }\n\n";
        
        $script .= "    if (isRoofingGroup) {\n";
        $script .= "      console.log('  -> Hiding beauty-specific elements');\n";
        $script .= "      gateCss += '.elementor-5334 .elementor-element.elementor-element-406be08{display:none!important;}';\n";
        $script .= "      gateCss += '.elementor-5334 .elementor-element.elementor-element-8d39fba{display:none!important;}';\n";
        $script .= "      gateCss += '.elementor-element-691ac29 div.elementor-widget-wrap.elementor-element-populated div.elementor-element.elementor-element-cbc9a76.elementor-align-center.elementor-widget.elementor-widget-elementskit-button{display:none!important;}';\n";
        $script .= "      gateCss += '.elementor-5352 .elementor-element.elementor-element-52e0966:not(.elementor-motion-effects-element-type-background){display:none!important;}';\n";
        $script .= "    }\n\n";
        
        $script .= "    gateStyle.textContent = gateCss;\n";
        $script .= "    document.head.appendChild(gateStyle);\n";
        $script .= "    console.log('✅ Gate CSS applied:', gateCss.length, 'characters');\n";

        
        if (!empty($changes['assets'])) {
            $script .= "    // Apply assets for active industry\n";
            
            foreach ($changes['assets'] as $asset) {
                $assetIndustry = $asset['industry'] ?? '';
                
                // Only apply assets for the active industry
                $script .= "    if (activeIndustry === '" . esc_js($assetIndustry) . "') {\n";
                
                $url = esc_js($asset['url']);
                $industry = !empty($asset['industry']) ? esc_js(ucwords(str_replace(['-', '_'], ' ', $asset['industry']))) : 'General';
                $key = !empty($asset['key']) ? esc_js($asset['key']) : 'asset';
                $type = $asset['type'] ?? 'default';
                $script .= "      console.log('Applying {$industry} / {$key} swap (type: {$type})');\n";
        
                $selectors = (array) ($asset['selectors'] ?? []);
                foreach ($selectors as $selector) {
                    $sel = addslashes($selector);
                    
                    if ($type === 'slideshow') {
                        // Slideshow background images
                        $script .= "      var els = document.querySelectorAll('{$sel}');\n";
                        $script .= "      console.log('  Found ' + els.length + ' elements for: {$sel}');\n";
                        $script .= "      els.forEach(function(el) {\n";
                        $script .= "        el.style.backgroundImage = 'url(\"{$url}\")';\n";
                        $script .= "      });\n";
                    } elseif ($type === 'service') {
                        // Service images
                        $script .= "      var els = document.querySelectorAll('{$sel}');\n";
                        $script .= "      console.log('  Found ' + els.length + ' elements for: {$sel}');\n";
                        $script .= "      els.forEach(function(el) {\n";
                        $script .= "        console.log('  Updating img:', el);\n";
                        $script .= "        el.src = '{$url}';\n";
                        $script .= "        el.srcset = '{$url}';\n";
                        $script .= "        el.style.maxWidth = '100%';\n";
                        $script .= "        el.style.objectFit = 'cover';\n";
                        $script .= "      });\n";
                    } elseif ($type === 'product') {
                        // Product images
                        $script .= "      var els = document.querySelectorAll('{$sel}');\n";
                        $script .= "      console.log('  Found ' + els.length + ' elements for: {$sel}');\n";
                        $script .= "      els.forEach(function(el) {\n";
                        $script .= "        console.log('  Updating product img:', el);\n";
                        $script .= "        el.src = '{$url}';\n";
                        $script .= "        el.srcset = '{$url}';\n";
                        $script .= "        el.style.aspectRatio = '1';\n";
                        $script .= "        el.style.objectFit = 'cover';\n";
                        $script .= "      });\n";
                    } else {
                        // Default image swap
                        $script .= "      var els = document.querySelectorAll('{$sel}');\n";
                        $script .= "      console.log('  Found ' + els.length + ' elements for: {$sel}');\n";
                        $script .= "      els.forEach(function(el) {\n";
                        $script .= "        el.src = '{$url}';\n";
                        $script .= "        el.srcset = '{$url}';\n";
                        $script .= "      });\n";
                    }
                }
        
                $widths = (array) ($asset['widths'] ?? []);
                foreach ($widths as $width) {
                    $selector = addslashes($width['selector']);
                    $value = esc_js($width['value']);
                    $script .= "      document.querySelectorAll('{$selector}').forEach(function(el) {\n";
                    $script .= "        el.style.width = '{$value}';\n";
                    $script .= "      });\n";
                }
        
                $script .= "    }\n"; // Close the if statement for this asset
                $script .= "\n";
            }
        }
        
        // Color replacements - target all possible Elementor global color variable names
        $color_targets = [
            'dark' => ['--e-global-color-6', '--e-global-color-15d0d07', '--e-global-color-secondary'],
            'light' => ['--e-global-color-4', '--e-global-color-d03c845', '--e-global-color-primary'],
        ];

        foreach ($color_targets as $key => $vars) {
            if (empty($changes['colors'][$key])) {
                continue;
            }
            $value = esc_js($changes['colors'][$key]);
            foreach ($vars as $var) {
                $script .= "    document.documentElement.style.setProperty('{$var}', '{$value}', 'important');\n";
            }
        }
        
        // Inject Contact Form Color Overrides CSS
        $dark_color = esc_js($changes['colors']['dark'] ?? '#1b1b1b');
        $light_color = esc_js($changes['colors']['light'] ?? '#15d0d07');
        
        $script .= "\n    // Inject Contact Form Color Override CSS\n";
        $script .= "    var styleId = 'bluzetta-contact-form-colors';\n";
        $script .= "    var existingStyle = document.getElementById(styleId);\n";
        $script .= "    if (existingStyle) existingStyle.remove();\n";
        $script .= "    var style = document.createElement('style');\n";
        $script .= "    style.id = styleId;\n";
        $script .= "    style.textContent = `\n";
        $script .= "      /* Contact Form Color Override - Auto Generated */\n";
        $script .= "      .bzcp-btn {\n";
        $script .= "        background: {$light_color} !important;\n";
        $script .= "        color: {$dark_color} !important;\n";
        $script .= "        border: 0 !important;\n";
        $script .= "        border-radius: 8px !important;\n";
        $script .= "        padding: 24px 28px !important;\n";
        $script .= "        font-weight: 700 !important;\n";
        $script .= "        font-size: 1.2rem !important;\n";
        $script .= "        box-shadow: 0 6px 18px rgba(0,0,0,.22) !important;\n";
        $script .= "      }\n";
        $script .= "      .bzcp-overlay {\n";
        $script .= "        background: rgba(0,0,0,.66) !important;\n";
        $script .= "      }\n";
        $script .= "      .bzcp-card {\n";
        $script .= "        background: {$dark_color} !important;\n";
        $script .= "        color: #f4f4f4 !important;\n";
        $script .= "        border: 2px solid {$light_color} !important;\n";
        $script .= "        border-radius: 16px !important;\n";
        $script .= "      }\n";
        $script .= "      .bzcp-card input[type=\"text\"],\n";
        $script .= "      .bzcp-card input[type=\"email\"],\n";
        $script .= "      .bzcp-card input[type=\"tel\"],\n";
        $script .= "      .bzcp-card textarea {\n";
        $script .= "        background: {$dark_color} !important;\n";
        $script .= "        color: #fff !important;\n";
        $script .= "        border: 2px solid {$light_color} !important;\n";
        $script .= "        border-radius: 10px !important;\n";
        $script .= "      }\n";
        $script .= "      .bzcp-card input[type=\"submit\"] {\n";
        $script .= "        background: {$light_color} !important;\n";
        $script .= "        color: {$dark_color} !important;\n";
        $script .= "        border: 1px solid {$light_color} !important;\n";
        $script .= "      }\n";
        $script .= "      .bzcp-card label {\n";
        $script .= "        color: #f4f4f4 !important;\n";
        $script .= "      }\n";
        $script .= "      [id^=\"bzcp_\"] .bzcp-btn {\n";
        $script .= "        background-color: {$light_color} !important;\n";
        $script .= "        color: {$dark_color} !important;\n";
        $script .= "      }\n";
        $script .= "      #bzcp_n3yjWI-wrap .bzcp-btn {\n";
        $script .= "        background-color: {$light_color} !important;\n";
        $script .= "        color: {$dark_color} !important;\n";
        $script .= "        border-color: {$light_color} !important;\n";
        $script .= "      }\n";
        $script .= "      .add-to-cart-btn {\n";
        $script .= "        background: {$dark_color} !important;\n";
        $script .= "        border-color: {$dark_color} !important;\n";
        $script .= "        color: {$light_color} !important;\n";
        $script .= "      }\n";
        $script .= "      .product-title {\n";
        $script .= "        color: {$dark_color} !important;\n";
        $script .= "      }\n";
        $script .= "      .product-description {\n";
        $script .= "        color: {$dark_color} !important;\n";
        $script .= "      }\n";
        $script .= "      .bluzetta-product-card {\n";
        $script .= "        background: {$light_color} !important;\n";
        $script .= "      }\n";
        $script .= "    `;\n";
        $script .= "    document.head.appendChild(style);\n";
        $script .= "    console.log('✅ Contact form colors applied');\n";
        
        $script .= "\n    console.log('✅ Template swap applied!');\n";
        $script .= "  }\n";
        $script .= "  if (document.readyState === 'loading') {\n";
        $script .= "    document.addEventListener('DOMContentLoaded', applySwaps);\n";
        $script .= "  } else {\n";
        $script .= "    applySwaps();\n";
        $script .= "  }\n";
        $script .= "  setTimeout(applySwaps, 500);\n";
        $script .= "  setTimeout(applySwaps, 1500);\n";
        $script .= "})();\n";
        
        return $script;
    }
    
}

class BluZetta_GitHub_Updater {
    const PLUGIN_SLUG = 'webapp360demo';
    const REPO = 'Blu-Zetta/demos';
    const MANIFEST_URL = 'https://raw.githubusercontent.com/Blu-Zetta/updates/main/webapp360demo/manifest.json';
    const CACHE_KEY = 'bluzetta_quick_setup_latest_release';
    const CACHE_TTL = 21600; // 6 hours
    const OPTION_TOKEN = 'bluzetta_github_token';

    public function __construct() {
        add_filter('pre_set_site_transient_update_plugins', array($this, 'inject_update'));
        add_filter('plugins_api', array($this, 'plugin_info'), 10, 3);
        add_action('upgrader_process_complete', array($this, 'clear_release_cache'), 10, 2);
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function add_settings_page() {
        add_options_page(
            'Blu Zetta Updater',
            'Blu Zetta Updater',
            'manage_options',
            'bluzetta-updater',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting(
            'bluzetta_updater',
            self::OPTION_TOKEN,
            array(
                'type' => 'string',
                'sanitize_callback' => array($this, 'sanitize_token'),
                'default' => '',
            )
        );

        add_settings_section(
            'bluzetta_updater_auth',
            'GitHub Authentication',
            '__return_false',
            'bluzetta-updater'
        );

        add_settings_field(
            self::OPTION_TOKEN,
            'GitHub Token',
            array($this, 'render_token_field'),
            'bluzetta-updater',
            'bluzetta_updater_auth'
        );
    }

    public function sanitize_token($token) {
        return trim((string) $token);
    }

    public function render_token_field() {
        $token_value = get_option(self::OPTION_TOKEN, '');
        if (!is_string($token_value)) {
            $token_value = '';
        }

        echo '<input type="password" class="regular-text" name="' . esc_attr(self::OPTION_TOKEN) . '" value="' . esc_attr($token_value) . '" autocomplete="off" />';
        echo '<p class="description">Used only for GitHub API fallback mode. If your public update manifest works, leave empty.</p>';

        if (defined('BLUZETTA_GITHUB_TOKEN') && BLUZETTA_GITHUB_TOKEN) {
            echo '<p class="description"><strong>wp-config.php token is active and overrides this field.</strong></p>';
        }
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="wrap">';
        echo '<h1>Blu Zetta Updater</h1>';
        echo '<p>Configure GitHub credentials used to check release updates.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('bluzetta_updater');
        do_settings_sections('bluzetta-updater');
        submit_button('Save Settings');
        echo '</form>';
        echo '</div>';
    }

    public function inject_update($transient) {
        if (!is_object($transient) || empty($transient->checked)) {
            return $transient;
        }

        $plugin_file = plugin_basename(__FILE__);
        $current_version = $this->get_current_version();
        if (!$current_version) {
            return $transient;
        }

        $release = $this->get_latest_release();
        if (!$release) {
            return $transient;
        }

        if (version_compare($release['version'], $current_version, '>')) {
            $update = array(
                'id' => 'github://' . self::REPO . '/' . self::PLUGIN_SLUG,
                'slug' => self::PLUGIN_SLUG,
                'plugin' => $plugin_file,
                'new_version' => $release['version'],
                'url' => $release['html_url'],
                'package' => $release['asset_url'],
            );

            if (!empty($release['requires'])) {
                $update['requires'] = $release['requires'];
            }

            if (!empty($release['tested'])) {
                $update['tested'] = $release['tested'];
            }

            if (!empty($release['requires_php'])) {
                $update['requires_php'] = $release['requires_php'];
            }

            $transient->response[$plugin_file] = (object) $update;
        }

        return $transient;
    }

    public function plugin_info($result, $action, $args) {
        if ('plugin_information' !== $action || empty($args->slug) || self::PLUGIN_SLUG !== $args->slug) {
            return $result;
        }

        $release = $this->get_latest_release();
        $current_version = $this->get_current_version();

        $version = $release ? $release['version'] : $current_version;
        $changelog = 'No changelog provided.';
        $description = 'Demo site configuration toolkit for Blu Zetta client mockups, including fast template swaps, brand assets, and page settings. App by Blu Zetta.';
        $release_url = 'https://github.com/' . self::REPO;
        $download_url = '';
        $last_updated = '';
        $requires = '';
        $tested = '';
        $requires_php = '';

        if ($release) {
            $changelog = !empty($release['body']) ? wp_kses_post(wpautop($release['body'])) : $changelog;
            $release_url = !empty($release['html_url']) ? $release['html_url'] : $release_url;
            $download_url = !empty($release['asset_url']) ? $release['asset_url'] : $download_url;
            $last_updated = !empty($release['published_at']) ? $release['published_at'] : $last_updated;
            if (!empty($release['description'])) {
                $description = wp_kses_post(wpautop($release['description']));
            }
            if (!empty($release['requires'])) {
                $requires = $release['requires'];
            }
            if (!empty($release['tested'])) {
                $tested = $release['tested'];
            }
            if (!empty($release['requires_php'])) {
                $requires_php = $release['requires_php'];
            }
        }

        return (object) array(
            'name' => 'Blu Zetta Demo Site Configs',
            'slug' => self::PLUGIN_SLUG,
            'version' => $version,
            'author' => 'Blu Zetta',
            'author_profile' => 'https://bluzetta.com',
            'homepage' => 'https://bluzetta.com',
            'download_link' => $download_url,
            'last_updated' => $last_updated,
            'requires' => $requires,
            'tested' => $tested,
            'requires_php' => $requires_php,
            'sections' => array(
                'description' => $description,
                'changelog' => $changelog,
            ),
            'external' => true,
        );
    }

    public function clear_release_cache($upgrader, $hook_extra) {
        if (empty($hook_extra['type']) || 'plugin' !== $hook_extra['type']) {
            return;
        }

        if (empty($hook_extra['plugins']) || !is_array($hook_extra['plugins'])) {
            return;
        }

        if (in_array(plugin_basename(__FILE__), $hook_extra['plugins'], true)) {
            delete_transient(self::CACHE_KEY);
        }
    }

    private function get_current_version() {
        $plugin_data = get_file_data(__FILE__, array('Version' => 'Version'));
        return !empty($plugin_data['Version']) ? trim($plugin_data['Version']) : '';
    }

    private function get_latest_release() {
        $cached = get_transient(self::CACHE_KEY);
        if (is_array($cached) && !empty($cached['version']) && !empty($cached['asset_url'])) {
            return $cached;
        }

        $release = $this->get_latest_release_from_manifest();
        if (!$release) {
            $release = $this->get_latest_release_from_github();
        }

        if ($release) {
            set_transient(self::CACHE_KEY, $release, self::CACHE_TTL);
        }

        return $release;
    }

    private function get_latest_release_from_manifest() {
        $manifest_url = $this->get_manifest_url();
        if (!$manifest_url) {
            return null;
        }

        $response = wp_remote_get($manifest_url, array(
            'timeout' => 15,
            'headers' => array(
                'Accept' => 'application/json',
                'User-Agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url('/'),
            ),
        ));

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return null;
        }

        $payload = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($payload)) {
            return null;
        }

        $version = '';
        if (!empty($payload['version'])) {
            $version = trim((string) $payload['version']);
        }

        $asset_url = '';
        if (!empty($payload['download_url'])) {
            $asset_url = esc_url_raw((string) $payload['download_url']);
        } elseif (!empty($payload['asset_url'])) {
            $asset_url = esc_url_raw((string) $payload['asset_url']);
        }

        if (!$version || !$asset_url) {
            return null;
        }

        return array(
            'version' => $version,
            'asset_url' => $asset_url,
            'html_url' => !empty($payload['html_url']) ? esc_url_raw((string) $payload['html_url']) : ('https://github.com/' . self::REPO),
            'published_at' => !empty($payload['published_at']) ? (string) $payload['published_at'] : '',
            'body' => !empty($payload['changelog']) ? (string) $payload['changelog'] : '',
            'description' => !empty($payload['description']) ? (string) $payload['description'] : '',
            'requires' => !empty($payload['requires']) ? (string) $payload['requires'] : '',
            'tested' => !empty($payload['tested']) ? (string) $payload['tested'] : '',
            'requires_php' => !empty($payload['requires_php']) ? (string) $payload['requires_php'] : '',
        );
    }

    private function get_latest_release_from_github() {
        $request_url = 'https://api.github.com/repos/' . self::REPO . '/releases/latest';
        $headers = array(
            'Accept' => 'application/vnd.github+json',
            'User-Agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url('/'),
        );

        $token = $this->get_auth_token();
        if ($token) {
            $headers['Authorization'] = 'Bearer ' . $token;
        }

        $response = wp_remote_get($request_url, array(
            'timeout' => 15,
            'headers' => $headers,
        ));

        if (is_wp_error($response)) {
            return null;
        }

        if (200 !== wp_remote_retrieve_response_code($response)) {
            return null;
        }

        $payload = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($payload) || empty($payload['tag_name']) || empty($payload['assets'])) {
            return null;
        }

        $asset_url = '';
        foreach ($payload['assets'] as $asset) {
            if (empty($asset['browser_download_url']) || empty($asset['name'])) {
                continue;
            }

            if (preg_match('/^webapp360demo-v.+\.zip$/', $asset['name'])) {
                $asset_url = $asset['browser_download_url'];
                break;
            }

            if (!$asset_url && preg_match('/\.zip$/', $asset['name'])) {
                $asset_url = $asset['browser_download_url'];
            }
        }

        if (!$asset_url) {
            return null;
        }

        $version = ltrim((string) $payload['tag_name'], 'v');
        if (!$version) {
            return null;
        }

        $release = array(
            'version' => $version,
            'asset_url' => $asset_url,
            'html_url' => !empty($payload['html_url']) ? $payload['html_url'] : ('https://github.com/' . self::REPO),
            'published_at' => !empty($payload['published_at']) ? $payload['published_at'] : '',
            'body' => !empty($payload['body']) ? $payload['body'] : '',
            'description' => '',
            'requires' => '',
            'tested' => '',
            'requires_php' => '',
        );

        return $release;
    }

    private function get_manifest_url() {
        if (defined('BLUZETTA_UPDATE_MANIFEST_URL') && BLUZETTA_UPDATE_MANIFEST_URL) {
            return esc_url_raw(trim((string) BLUZETTA_UPDATE_MANIFEST_URL));
        }

        return esc_url_raw((string) apply_filters('bluzetta_quick_setup_manifest_url', self::MANIFEST_URL));
    }

    private function get_auth_token() {
        if (defined('BLUZETTA_GITHUB_TOKEN') && BLUZETTA_GITHUB_TOKEN) {
            return trim((string) BLUZETTA_GITHUB_TOKEN);
        }

        $stored = get_option(self::OPTION_TOKEN, '');
        if (!is_string($stored)) {
            return '';
        }

        return trim($stored);
    }
}

// Initialize the plugin
new BluZetta_GitHub_Updater();
new BluZetta_Quick_Setup();

// Inject the script on frontend
add_action('wp_footer', function() {
    $script = get_option('template_swapper_active_script');
    $target_page = get_option('template_swapper_target_page');
    
    if ($script) {
        // If target page specified, only apply there
        if ($target_page && is_page($target_page)) {
            echo '<script>' . $script . '</script>';
        } elseif (!$target_page) {
            // Apply to all pages if no target specified
            echo '<script>' . $script . '</script>';
        }
    }
}, 999);

// Add postMessage listener for real-time color preview from admin
add_action('wp_footer', function() {
    ?>
    <script>
    (function() {
        var colorVars = {
            dark: ['--e-global-color-6', '--e-global-color-15d0d07', '--e-global-color-secondary'],
            light: ['--e-global-color-4', '--e-global-color-d03c845', '--e-global-color-primary']
        };
        
        window.addEventListener('message', function(event) {
            // Check if it's our color preview message
            if (event.data && event.data.type === 'bluzetta_color_preview') {
                var colors = event.data.colors;
                if (colors.dark) {
                    colorVars.dark.forEach(function(varName) {
                        document.documentElement.style.setProperty(varName, colors.dark, 'important');
                    });
                }
                if (colors.light) {
                    colorVars.light.forEach(function(varName) {
                        document.documentElement.style.setProperty(varName, colors.light, 'important');
                    });
                }
            }
        });
    })();
    </script>
    <?php
}, 1000);




// 1. Add admin menu
add_action('admin_menu', 'cpc_add_admin_menu');
function cpc_add_admin_menu() {
    add_menu_page(
        'Create WebApp Demo',
        'New Client Demo',
        'edit_posts',
        'custom-post-creator',
        'cpc_render_admin_page',
        'dashicons-welcome-view-site',
        25
    );

    add_submenu_page(
        'custom-post-creator',
        'All WebApp Demos',
        'All WebApp Demos',
        'edit_posts',
        'cpc-demo-list',
        'cpc_render_demo_list_page'
    );
}

// 2. Render the admin page
function cpc_render_admin_page() {
    // Handle form submission
    if (isset($_POST['cpc_submit']) && check_admin_referer('cpc_create_post', 'cpc_nonce')) {
        $result = cpc_create_post();
    }
    
    wp_enqueue_media();
    ?>
    <div class="wrap">
        <h1>Create New WebApp Demo</h1>
        
        <?php if (isset($result)): ?>
            <?php if ($result['success']): ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>Demo created successfully!</strong></p>
                    <p>
                        <strong>URL:</strong> 
                        <input type="text" id="created-post-url" value="<?php echo esc_attr($result['url']); ?>" style="width: 60%; margin: 0 10px;" readonly>
                        <button type="button" class="button" onclick="copyPostUrl()">📋 Copy URL</button>
                        <a href="<?php echo esc_url($result['url']); ?>" class="button" target="_blank">View Demo</a>
                        <a href="<?php echo esc_url($result['edit_url']); ?>" class="button">Edit Demo</a>
                    </p>
                </div>
            <?php else: ?>
                <div class="notice notice-error is-dismissible">
                    <p><strong>Error:</strong> <?php echo esc_html($result['message']); ?></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="post" id="cpc-form">
            <?php wp_nonce_field('cpc_create_post', 'cpc_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="post_title">Business Name<span style="color:red;">*</span></label>
                    </th>
                    <td>
                        <input type="text" name="post_title" id="post_title" class="regular-text" required>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="post_slug">Demo URL</label>
                    </th>
                    <td>
                        <input type="text" name="post_slug" id="post_slug" class="regular-text">
                        <p class="description">Leave blank to auto-generate from title. Example: business-name</p>
                        <div id="url-preview" style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-left: 4px solid #2271b1; display:none;">
                            <strong>URL Preview:</strong> <span id="preview-url"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <th scope="row" style="border-top: 2px solid #ddd; padding-top: 20px;">
                        <h3 style="margin: 0;">Business Contact Details</h3>
                    </th>
                    <td style="border-top: 2px solid #ddd;"></td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="demo_region">Region</label>
                    </th>
                    <td>
                        <select name="demo_region" id="demo_region" class="regular-text">
                            <option value="">Select region</option>
                            <option value="UK">UK</option>
                            <option value="USA">USA</option>
                            <option value="AUS">AUS</option>
                            <option value="CAN">CAN</option>
                        </select>
                        <p class="description">Used for pricing currency. Default is UK if not selected.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="custom_email">Official Business Email <span style="color:red;">*</span></label>
                    </th>
                    <td>
                        <input type="email" name="custom_email" id="custom_email" class="regular-text" required>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row" style="border-top: 2px solid #ddd; padding-top: 20px;">
                        <h3 style="margin: 0;">Pricing / Special Offer</h3>
                    </th>
                    <td style="border-top: 2px solid #ddd;"></td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="demo_standard_price">Standard Price</label>
                    </th>
                    <td>
                        <input type="text" name="demo_standard_price" id="demo_standard_price" class="regular-text" value="£697.00">
                        <p class="description">Default is £697.00 (GBP). This will be converted based on region.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="demo_discount_enabled">Enable 50% Discount</label>
                    </th>
                    <td>
                        <label><input type="checkbox" name="demo_discount_enabled" id="demo_discount_enabled" value="1" checked> Enable 50% discount</label>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="demo_discount_duration">Offer Duration</label>
                    </th>
                    <td>
                        <select name="demo_discount_duration" id="demo_discount_duration" class="regular-text">
                            <option value="3">3 days</option>
                            <option value="7" selected>7 days (default)</option>
                        </select>
                        <p class="description">How long the discount offer will be active from publish date.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="demo_discount_price">Discount Price (optional)</label>
                    </th>
                    <td>
                        <input type="text" name="demo_discount_price" id="demo_discount_price" class="regular-text" placeholder="Leave blank for 50%">
                        <p class="description">Enter a custom discounted price in GBP (£). If blank, 50% is applied and converted by region.</p>
                    </td>
                </tr>


                <tr>
                    <th scope="row">
                        <label>Demo Video</label>
                    </th>
                    <td>
                        <input type="hidden" name="custom_video" id="custom_video" value="">
                        <button type="button" class="button" id="upload_video_button">
                            🎥 Select Video from Media Library
                        </button>
                        <button type="button" class="button" id="remove_video_button" style="display:none;">
                            ❌ Remove Video
                        </button>
                        <div id="video_preview" style="margin-top: 10px; display:none;">
                            <strong>Selected Video:</strong> <span id="video_filename"></span>
                        </div>
                        <p class="description">Optional: Upload or select a video from the media library.</p>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <input type="submit" name="cpc_submit" id="submit" class="button button-primary button-large" value="Create Post">
            </p>
        </form>
    </div>

    <script>
    jQuery(document).ready(function($){
        // URL preview
        var siteUrl = '<?php echo esc_js(home_url('/')); ?>';
        
        function updatePreview() {
            var slug = $('#post_slug').val().trim();
            if (!slug) {
                var title = $('#post_title').val();
                slug = title.toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
            }
            
            if (slug) {
                $('#preview-url').text(siteUrl + slug + '/');
                $('#url-preview').show();
            } else {
                $('#url-preview').hide();
            }
        }
        
        $('#post_title, #post_slug').on('input', updatePreview);
        
        // Copy URL button
        window.copyPostUrl = function() {
            var urlInput = document.getElementById('created-post-url');
            urlInput.select();
            urlInput.setSelectionRange(0, 99999); // For mobile
            document.execCommand('copy');
            
            var btn = event.target;
            var originalText = btn.innerHTML;
            btn.innerHTML = '✅ Copied!';
            setTimeout(function() {
                btn.innerHTML = originalText;
            }, 2000);
        };

        // Video uploader
        var videoUploader;
        
        $('#upload_video_button').on('click', function(e){
            e.preventDefault();
            
            if (videoUploader) {
                videoUploader.open();
                return;
            }
            
            videoUploader = wp.media({
                title: 'Select Video',
                button: { text: 'Use this video' },
                multiple: false,
                library: { type: 'video' }
            });
            
            videoUploader.on('select', function(){
                var attachment = videoUploader.state().get('selection').first().toJSON();
                $('#custom_video').val(attachment.id);
                $('#video_filename').text(attachment.filename || attachment.title);
                $('#video_preview').show();
                $('#remove_video_button').show();
            });
            
            videoUploader.open();
        });
        
        $('#remove_video_button').on('click', function(e){
            e.preventDefault();
            $('#custom_video').val('');
            $('#video_preview').hide();
            $(this).hide();
        });
    });
    </script>

    <style>
        .form-table th {
            width: 200px;
        }
        #url-preview {
            word-break: break-all;
        }
    </style>
    <?php
}



// 2b. Render the demo list page (redirect to filtered posts list)
function cpc_render_demo_list_page() {
    if (!current_user_can('edit_posts')) {
        return;
    }

    $url = admin_url('edit.php?post_type=post&cpc_demo=1');
    wp_safe_redirect($url);
    exit;
}


// Pricing helpers
function cpc_parse_price_to_float($raw) {
    $clean = preg_replace('/[^0-9.]/', '', (string) $raw);
    if ($clean === '') {
        return 0.0;
    }
    return (float) $clean;
}

function cpc_format_price($amount) {
    $num = is_numeric($amount) ? (float) $amount : cpc_parse_price_to_float($amount);
    return number_format($num, 2, '.', '');
}

function cpc_get_currency_for_region($region) {
    $map = [
        'UK' => ['code' => 'GBP', 'symbol' => '£'],
        'USA' => ['code' => 'USD', 'symbol' => '$'],
        'AUS' => ['code' => 'AUD', 'symbol' => 'A$'],
        'CAN' => ['code' => 'CAD', 'symbol' => 'C$'],
    ];
    return $map[$region] ?? $map['UK'];
}

function cpc_get_exchange_rate($base, $target) {
    if ($base === $target) {
        return 1.0;
    }

    $transient_key = 'cpc_rate_' . strtolower($base . '_' . $target);
    $cached = get_transient($transient_key);
    if (!empty($cached)) {
        return (float) $cached;
    }

    $url = 'https://open.er-api.com/v6/latest/' . rawurlencode($base);
    $response = wp_remote_get($url, ['timeout' => 10]);
    if (is_wp_error($response)) {
        return 0.0;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!is_array($data) || empty($data['rates'][$target])) {
        return 0.0;
    }

    $rate = (float) $data['rates'][$target];
    if ($rate > 0) {
        set_transient($transient_key, $rate, DAY_IN_SECONDS);
    }

    return $rate;
}

function cpc_build_pricing_meta($region, $standard_price_gbp, $discount_enabled, $discount_price_gbp = null) {
    $allowed = ['UK', 'USA', 'AUS', 'CAN'];
    if (!in_array($region, $allowed, true)) {
        $region = 'UK';
    }

    $currency = cpc_get_currency_for_region($region);
    $rate = 1.0;

    if ($currency['code'] !== 'GBP') {
        $rate = cpc_get_exchange_rate('GBP', $currency['code']);
        if ($rate <= 0) {
            $region = 'UK';
            $currency = cpc_get_currency_for_region($region);
            $rate = 1.0;
        }
    }

    $standard_converted = round($standard_price_gbp * $rate, 2);

    $discount_base_gbp = null;
    if ($discount_price_gbp !== null && $discount_price_gbp > 0) {
        $discount_base_gbp = $discount_price_gbp;
    } else {
        $discount_base_gbp = $standard_price_gbp * 0.5;
    }

    $discount_converted = round($discount_base_gbp * $rate, 2);

    return [
        'region' => $region,
        'currency_code' => $currency['code'],
        'currency_symbol' => $currency['symbol'],
        'exchange_rate' => $rate,
        'standard_price' => number_format($standard_converted, 2, '.', ''),
        'discount_price' => number_format($discount_converted, 2, '.', ''),
        'discount_price_gbp' => number_format($discount_base_gbp, 2, '.', ''),
        'discount_enabled' => $discount_enabled ? 1 : 0,
    ];
}

// 3. Handle post creation
function cpc_create_post() {
    // Validate required fields
    if (empty($_POST['post_title']) || empty($_POST['custom_email'])) {
        return [
            'success' => false,
            'message' => 'Please fill in all required fields (Business Name, Official Business Email).'
        ];
    }

    // Prepare post data

    $region = isset($_POST['demo_region']) ? strtoupper(sanitize_text_field($_POST['demo_region'])) : '';
    $raw_standard_price = isset($_POST['demo_standard_price']) ? sanitize_text_field($_POST['demo_standard_price']) : '';
    $standard_price_gbp = cpc_parse_price_to_float($raw_standard_price);
    if ($standard_price_gbp <= 0) {
        $standard_price_gbp = 697.00;
    }
    $discount_enabled = !empty($_POST['demo_discount_enabled']);
    $raw_discount_price = isset($_POST['demo_discount_price']) ? sanitize_text_field($_POST['demo_discount_price']) : '';
    $discount_price_gbp = cpc_parse_price_to_float($raw_discount_price);
    if ($discount_price_gbp <= 0) {
        $discount_price_gbp = null;
    }
    $pricing = cpc_build_pricing_meta($region, $standard_price_gbp, $discount_enabled, $discount_price_gbp);


    // Ensure the demo category exists and capture its ID
    $demo_category_id = 0;
    $demo_category = get_category_by_slug('demos');
    if ($demo_category) {
        $demo_category_id = (int) $demo_category->term_id;
    } else {
        $created = wp_insert_term('Demos', 'category', ['slug' => 'demos']);
        if (!is_wp_error($created)) {
            $demo_category_id = (int) $created['term_id'];
        }
    }

    $post_data = [
        'post_title'   => sanitize_text_field($_POST['post_title']),
        'post_status'  => 'publish',
        'post_type'    => 'post',
        'post_author'  => get_current_user_id(),
        'post_category' => $demo_category_id ? [$demo_category_id] : [],
    ];

    // Add custom slug if provided
    if (!empty($_POST['post_slug'])) {
        $post_data['post_name'] = sanitize_title($_POST['post_slug']);
    }

    // Create the post
    $post_id = wp_insert_post($post_data);

    if (is_wp_error($post_id)) {
        return [
            'success' => false,
            'message' => 'Failed to create post: ' . $post_id->get_error_message()
        ];
    }

    // Ensure demo category is assigned
    if (empty($demo_category_id)) {
        $demo_category = get_category_by_slug('demos');
        if ($demo_category) {
            $demo_category_id = (int) $demo_category->term_id;
        }
    }
    if (!empty($demo_category_id)) {
        wp_set_post_categories($post_id, [$demo_category_id], false);
    }

    // Save custom meta fields
    update_post_meta($post_id, '_custom_email', sanitize_email($_POST['custom_email']));
    update_post_meta($post_id, '_cpc_demo', 1);
    update_post_meta($post_id, '_demo_region', $pricing['region']);
    update_post_meta($post_id, '_demo_currency_code', $pricing['currency_code']);
    update_post_meta($post_id, '_demo_currency_symbol', $pricing['currency_symbol']);
    update_post_meta($post_id, '_demo_standard_price', $pricing['standard_price']);
    update_post_meta($post_id, '_demo_discount_price', $pricing['discount_price']);
    update_post_meta($post_id, '_demo_discount_price_gbp', $pricing['discount_price_gbp']);
    update_post_meta($post_id, '_demo_discount_enabled', $pricing['discount_enabled']);
    update_post_meta($post_id, '_demo_exchange_rate', $pricing['exchange_rate']);
    // Save discount duration (3 or 7 days)
    $discount_duration = isset($_POST['demo_discount_duration']) ? intval($_POST['demo_discount_duration']) : 7;
    if (!in_array($discount_duration, [3, 7])) {
        $discount_duration = 7; // fallback to default
    }
    update_post_meta($post_id, '_demo_discount_duration', $discount_duration);
    update_post_meta($post_id, '_demo_price_gbp', number_format($standard_price_gbp, 2, '.', ''));

    
    if (!empty($_POST['custom_video'])) {
        update_post_meta($post_id, '_custom_video', intval($_POST['custom_video']));
    }

    return [
        'success' => true,
        'post_id' => $post_id,
        'url' => get_permalink($post_id),
        'edit_url' => get_edit_post_link($post_id, 'raw')
    ];
}


// Filter admin list to only show demo posts when requested
add_action('pre_get_posts', 'cpc_filter_demo_posts_admin');
function cpc_filter_demo_posts_admin($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    if (empty($_GET['cpc_demo'])) {
        return;
    }

    $post_type = $query->get('post_type');
    if (!empty($post_type) && $post_type !== 'post') {
        return;
    }

    $query->set('category_name', 'demos');
}


// Admin list: add Business Email column for demo list
add_filter('manage_edit-post_columns', 'cpc_add_demo_email_column');
function cpc_add_demo_email_column($columns) {
    if (empty($_GET['cpc_demo'])) {
        return $columns;
    }

    $new_columns = [];
    foreach ($columns as $key => $label) {
        $new_columns[$key] = $label;
        if ($key === 'title') {
            $new_columns['cpc_demo_email'] = 'Business Email';
        }
    }

    if (!isset($new_columns['cpc_demo_email'])) {
        $new_columns['cpc_demo_email'] = 'Business Email';
    }

    return $new_columns;
}

add_action('manage_post_posts_custom_column', 'cpc_render_demo_email_column', 10, 2);
function cpc_render_demo_email_column($column, $post_id) {
    if ($column !== 'cpc_demo_email') {
        return;
    }

    $email = get_post_meta($post_id, '_custom_email', true);
    echo esc_html($email ?: '—');
}

// Enforce demo category for demo posts
add_action('save_post', 'cpc_enforce_demo_category', 20, 2);
function cpc_enforce_demo_category($post_id, $post) {
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }
    if (!$post || $post->post_type !== 'post') {
        return;
    }

    $has_demo_meta = get_post_meta($post_id, '_cpc_demo', true);
    $has_email_meta = metadata_exists('post', $post_id, '_custom_email');

    if (!$has_demo_meta && !$has_email_meta) {
        return;
    }

    if (!$has_demo_meta) {
        update_post_meta($post_id, '_cpc_demo', 1);
    }

    $demo_category = get_category_by_slug('demos');
    if (!$demo_category) {
        $created = wp_insert_term('Demos', 'category', ['slug' => 'demos']);
        if (is_wp_error($created)) {
            return;
        }
        $demo_category_id = (int) $created['term_id'];
    } else {
        $demo_category_id = (int) $demo_category->term_id;
    }

    $current_categories = wp_get_post_categories($post_id);
    if (count($current_categories) != 1 || !in_array($demo_category_id, $current_categories, true)) {
        wp_set_post_categories($post_id, [$demo_category_id], false);
    }
}

// 4. Shortcode to display video (keep from your original code)
function display_custom_video_shortcode($atts) {
    global $post;
    $video_id = get_post_meta($post->ID, '_custom_video', true);
    if (!$video_id) return '';
    
    $video_url = wp_get_attachment_url($video_id);
    if (!$video_url) return '';
    
    ob_start(); ?>
    <div class="custom-video-wrapper" style="text-align:center;">
        <button class="play-video-btn" style="font-size:20px; padding:20px 25px; font-weight:bold; cursor:pointer; border:2px solid blue; background:#fff; color: blue; border-radius: 90px;">
            <i class="fas fa-play"></i> See How Your New Site Works
        </button>
        <video width="800" style="margin:20px auto; max-width:100%; display:block;" preload="auto">
            <source src="<?php echo esc_url($video_url); ?>" type="video/mp4">
        </video>
    </div>
    <script>
    jQuery(document).ready(function($){
        $('.custom-video-wrapper .play-video-btn').on('click', function(){
            var $btn = $(this);
            var $icon = $btn.find('i');
            var video = $btn.siblings('video')[0];

            if (video.paused) {
                video.play();
                $icon.removeClass('fa-play').addClass('fa-pause');
            } else {
                video.pause();
                $icon.removeClass('fa-pause').addClass('fa-play');
            }
        });

        $('.custom-video-wrapper video').on('ended', function(){
            var $btn = $(this).siblings('.play-video-btn');
            $btn.find('i').removeClass('fa-pause').addClass('fa-play');
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('custom_video', 'display_custom_video_shortcode');


// 4b. Shortcode to display pricing/offer
function display_demo_pricing_shortcode($atts) {
    global $post;
    if (!$post) {
        return '';
    }

    $discount_meta = get_post_meta($post->ID, '_demo_discount_enabled', true);
    $discount_enabled = $discount_meta === '' ? 1 : (int) $discount_meta;

    $currency_code = get_post_meta($post->ID, '_demo_currency_code', true) ?: 'GBP';
    $currency_symbol = get_post_meta($post->ID, '_demo_currency_symbol', true) ?: '£';

    $standard_price = get_post_meta($post->ID, '_demo_standard_price', true);
    if ($standard_price === '') {
        $standard_price = '697.00';
    }

    $discount_price = get_post_meta($post->ID, '_demo_discount_price', true);
    if ($discount_price === '') {
        $discount_price = cpc_format_price(((float) $standard_price) * 0.5);
    }

    $price_prefix = $currency_code . ' ' . $currency_symbol;
    $standard_display = $price_prefix . cpc_format_price($standard_price);
    $discount_display = $price_prefix . cpc_format_price($discount_price);

    $published_ts = get_post_time('U', true, $post);
    if (!$published_ts) {
        $published_ts = time();
    }
    
    // Get discount duration (3 or 7 days, default 7)
    $discount_duration = get_post_meta($post->ID, '_demo_discount_duration', true);
    if (empty($discount_duration) || !in_array((int)$discount_duration, [3, 7])) {
        $discount_duration = 7; // default to 7 days
    }
    
    $expires_ts = $published_ts + ((int)$discount_duration * DAY_IN_SECONDS);
    $expired = time() >= $expires_ts;
    $offer_active = $discount_enabled && !$expired;

    ob_start(); ?>
    <?php if ($discount_enabled): ?>
    <div class="demo-offer-box" data-expiry="<?php echo esc_attr($expires_ts); ?>" data-active="<?php echo $offer_active ? 1 : 0; ?>">
        <div class="demo-offer-standard">Normal Setup: <?php echo esc_html($standard_display); ?></div>
        <div class="demo-offer-discount">Your Price: <?php echo esc_html($discount_display); ?></div>
        <div class="demo-offer-timer">
            <i class="fas fa-clock"></i>
            <span class="demo-offer-timer-label">Offer ends in:</span>
            <span class="demo-offer-timer-value"><?php echo $expired ? 'Offer expired' : ''; ?></span>
        </div>
    </div>
    <?php endif; ?>
    <script>
    jQuery(document).ready(function($){
        var offerActive = <?php echo $offer_active ? 'true' : 'false'; ?>;
        var expiry = <?php echo (int) $expires_ts; ?> * 1000;

        function toggleOffer(active) {
            var $claimDemo = $('#ClaimDemo, .ClaimDemo');
            var $claimOffer = $('#ClaimOffer, .ClaimOffer');
            if (active) {
                $claimDemo.hide();
                $claimOffer.show();
            } else {
                $claimOffer.hide();
                $claimDemo.show();
            }
        }

        toggleOffer(offerActive);

        var $box = $('.demo-offer-box');
        if ($box.length) {
            var $timer = $box.find('.demo-offer-timer-value');

            function pad(n) {
                return (n < 10 ? '0' : '') + n;
            }

            function updateTimer() {
                var now = Date.now();
                var diff = expiry - now;
                if (diff <= 0) {
                    $timer.text('Offer expired');
                    toggleOffer(false);
                    return;
                }

                var totalSeconds = Math.floor(diff / 1000);
                var days = Math.floor(totalSeconds / 86400);
                var hours = Math.floor((totalSeconds % 86400) / 3600);
                var minutes = Math.floor((totalSeconds % 3600) / 60);
                var seconds = totalSeconds % 60;

                $timer.text(days + 'd ' + pad(hours) + 'h ' + pad(minutes) + 'm ' + pad(seconds) + 's');
            }

            updateTimer();
            setInterval(updateTimer, 1000);
        }
    });
    </script>
    <style>
    .demo-offer-box {
        padding: 16px 20px;
        margin: 20px 0;
        margin-right: 0px;
        margin-left: 0px;
        background: none;
        max-width: 700px;
        border-style: dotted;
        border-width: 1px;
        border-color: #FFFFFF;
        border-radius: 7px;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
    }
    .demo-offer-standard {
        color: #FFFFFF;
        font-size: 18px;
        font-weight: 700;
        text-decoration: line-through;
        margin-bottom: 6px;
    }
    .demo-offer-discount {
        color: #FFFFFF;
        font-size: 26px;
        font-weight: 800;
        margin-bottom: 12px;
    }
    .demo-offer-timer {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px;
        border-radius: 999px;
        background: #FFFFFF;
        color: #1d4ed8;
        font-size: 14px;
        font-weight: 700;
        margin: 0 auto;
    }
    .demo-offer-timer-value {
        font-family: monospace;
    }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('demo_pricing', 'display_demo_pricing_shortcode');

// 5. Shortcode for search by email (keep from your original code)
function custom_search_shortcode() {
    ob_start(); ?>
    <div class="custom-search-wrapper">
        <div class="custom-search-error" id="custom-search-error" style="color:red; margin-bottom:10px; display:none;"></div>
        <form method="get" class="custom-search-form" style="margin-bottom:20px;">
            <input type="text" name="cs_query" placeholder="Enter official business email" required style="padding:10px; width:100%; border-color: white !important; max-width:100%;">
            <button type="submit" style="padding:10px 20px; cursor:pointer;">Search</button>
        </form>
    </div>
    <script>
    jQuery(document).ready(function($){
        $('.custom-search-form').on('submit', function(e){
            e.preventDefault();
            var val = $('input[name="cs_query"]').val().trim();
            if (!val) return;
            
            $('#custom-search-error').hide();
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: { action: 'custom_search_post', query: val },
                success: function(res){
                    if(res.url) {
                        window.location.href = res.url;
                    } else {
                        $('#custom-search-error').text('No post found with that official business email.').show();
                    }
                },
                error: function() {
                    $('#custom-search-error').text('Search failed. Please try again.').show();
                }
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('custom_search', 'custom_search_shortcode');

// 6. AJAX handler for search by email (keep from your original code)
function handle_custom_search() {
    $query = sanitize_text_field($_POST['query']);
    
    $args = [
        'post_type' => 'post',
        'posts_per_page' => 1,
        'meta_query' => [
            ['key' => '_custom_email', 'value' => $query, 'compare' => '='],
        ]
    ];
    
    $posts = get_posts($args);
    
    if ($posts) {
        wp_send_json(['url' => get_permalink($posts[0]->ID)]);
    } else {
        wp_send_json(['url' => '']);
    }
}
add_action('wp_ajax_custom_search_post', 'handle_custom_search');
add_action('wp_ajax_nopriv_custom_search_post', 'handle_custom_search');
